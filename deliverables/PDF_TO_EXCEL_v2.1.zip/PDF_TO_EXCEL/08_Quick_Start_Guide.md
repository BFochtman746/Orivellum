# Quick Start Guide — PDF-to-Excel Conversion

## For First-Time Users

### Step 1: Prepare Your Reference Pack (One-Time Setup)

1. Create a folder on your computer: `PDF_to_Excel_Protocol/`
2. Copy these 7 files into it:
   - `01_Master_Prompt.md`
   - `02_Reference_Document_Pack_Specification.md`
   - `03_Quality_Checklist.md`
   - `04_Design_Rationale.md`
   - `05_Edge_Case_Reference_Template.md`
   - `06_Data_Flow_Diagram_Template.md`
   - `07_Post_Mortem_Lessons_Learned.md`
3. Fill in the templates with your company's specific conventions
4. Build one `_Style_Template.xlsx` using the specification in File 2
5. Build one `_Perfect_Example.pdf` + `_Perfect_Example.xlsx`

### Step 2: For Each Conversion

1. **Upload the source PDF** to the chat
2. **Upload your reference pack** (all `_` files + templates)
3. **Paste the Master Prompt** (from File 1)
4. **Add any context:** "This is a Q4 report, not Q3" or "The scanned page on page 8 should be a placeholder"
5. **Wait for delivery** + backwards-check report
6. **Run your own spot-checks** using the Quality Checklist

### Step 3: If Something Is Wrong

**Do NOT say "fix it."** Say exactly:

```
Cell [SHEET]![CELL] shows [ACTUAL] but the PDF shows [EXPECTED].
The formula is [FORMULA] but should be [CORRECT_FORMULA].
```

Example:
```
Cell Headcount!D8 shows =SUM(E5:E7) but should be =SUM(D5:D7).
The manual sum is 507 (412+58+37) but the cell shows 507.
```

Specificity = speed of correction.

---

## For Returning Users

### If You Already Have the Reference Pack

Just upload the PDF + reference pack + paste the prompt. Done.

### If the PDF Is Unusual

Before uploading, check:
- [ ] Is it scanned or born-digital? (Scanned = mention it)
- [ ] Does it have handwriting? (Mention it + upload handwriting samples if available)
- [ ] Does it have tables without gridlines? (Mention it)
- [ ] Does it span multiple pages with repeated headers? (Mention it)
- [ ] Does it have footnotes with restatements? (Mention it)
- [ ] Does it have N/A, blank, or "—" in numeric columns? (Mention it)

### If You Want to Update an Existing Workbook

1. Upload the previous version as `_Previous_Version.xlsx`
2. Upload the new PDF
3. Say: "Update the existing workbook with Q4 data. Preserve all structure and formulas."
4. The AI will diff the old vs new and update only changed cells

---

## Troubleshooting

| Problem | Cause | Solution |
|---------|-------|----------|
| AI ignores demo files | Files uploaded after prompt | Upload reference files BEFORE the PDF, at the start of the chat |
| Formulas are wrong | AI didn't backwards-check | Paste the Quality Checklist and demand the audit report |
| Style is inconsistent | Missing `_Style_Template.xlsx` | Build and upload the style template |
| Cross-sheet links broken | Missing `_Data_Flow_Diagram.txt` | Upload the diagram showing expected links |
| Edge cases mishandled | Missing `_Edge_Case_Reference` | Fill in the template with your domain's specific cases |
| Report narrative is generic | Missing `_Perfect_Example` | Build one perfect example showing your expected tone and structure |
| Delivery is too fast | AI is rushing | Paste: "Do not deliver until you have completed the full Quality Checklist" |

---

## Time Estimates

| Task | Time |
|------|------|
| One-time reference pack setup | 2–4 hours |
| Each conversion (simple PDF, 1–5 pages) | 10–15 minutes of chat time |
| Each conversion (complex PDF, 10+ pages, scanned) | 20–30 minutes of chat time |
| Your spot-check verification | 5 minutes |
| Total per conversion | 15–35 minutes |

Compare to: Manual rebuild from PDF = 2–4 hours per document.

---

## Contact / Feedback

If you discover a new edge case, a better convention, or a gap in the protocol:
1. Add it to the Edge Case Reference
2. Update the Quality Checklist
3. Share the improvement

This is a living document. It improves with every conversion.
