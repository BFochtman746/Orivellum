# Source Rendering and Transcription SOP

## Authority hierarchy

1. Rendered page image
2. Original PDF viewed directly
3. Neighboring page and section structure
4. Printed subtotals and arithmetic controls
5. PDF text layer
6. OCR output

A lower source cannot override a higher source without a documented reason.

## Rendering standard

### Default

Render modern textual pages at 300 ppi.

### Escalation

Use 400 ppi when:

- print is small
- digits touch rules or gridlines
- punctuation or parentheses are unclear
- footnotes are dense
- OCR and visual readings conflict

Use 600 ppi when:

- a critical digit remains unresolved at 400 ppi
- the scan is degraded
- a tiny crop is required
- microprint or faint marks materially affect interpretation

### Orientation

- save the original render
- create a separate upright derivative
- never crop away source content in the archival full-page render
- create separate crops for detailed review
- do not enhance, erase, redraw, or alter source marks
- document any contrast or sharpening used for a review derivative

## Page-render checklist

For every page:

- file opens
- correct page number
- correct orientation
- complete page boundary visible
- no clipping
- no accidental rescaling that changes source proportions
- readable at 100% zoom
- printed page number identified
- hash recorded
- page registered

## Transcription order

1. Page and section metadata
2. Row identity and source order
3. Labels and descriptions
4. Numeric source values
5. Footnotes and markers
6. Row type
7. Calculated formulas
8. Variance and status
9. reviewer notes
10. exception or decision ID

## Numeric rules

### Blank

A blank is stored as blank.

Do not convert blank to zero unless:

- the source explicitly states zero, or
- a governing schema defines blank as zero and that rule is documented.

### Zero

Store explicit zero as numeric zero.

### Parentheses

In a numeric context, `(123)` is stored as `-123`, unless the source clearly uses parentheses for another meaning.

### Dash and em dash

Preserve as a source marker or blank-state code. Do not assume zero.

### Currency symbols and commas

Store numeric value without formatting characters and apply an Excel number format.

### Percentages

Store as a numeric percentage or explicit percentage point according to the source. Preserve the printed percentage even when it does not equal the displayed numerator and denominator; calculate the independent ratio separately.

### Rounding

Do not force rounded detail to equal rounded totals. Preserve displayed rows and displayed totals, then record the difference.

## Text rules

- preserve names, titles, punctuation, and capitalization
- preserve paragraph numbering
- preserve footnote markers
- retain page and section context
- do not modernize historical spelling
- do not paraphrase source narrative in the transcription sheet
- summaries belong in a Report sheet, not in source-text fields

## Multi-page table rules

- remove repeated header rows from structured detail
- preserve the repeated header in page evidence
- continue an entity only when supported visually
- use source order to prevent duplicates
- store page number on every row
- identify split rows explicitly
- do not combine source rows merely because descriptions are similar

## Source total rule

When a printed total disagrees with verified detail:

- retain the printed total as a source value
- calculate detail independently
- calculate variance
- investigate transcription first
- create an exception only after rechecking
- never add a balancing row
