# PDF-to-Excel Controlled Conversion Protocol v2.0

## Purpose

This protocol converts complex PDFs into traceable, formula-driven Excel workbooks while minimizing unnecessary user questions. It is designed for financial reports, historical documents, large schedules, mixed narrative-and-table reports, rotated scans, and documents containing internal inconsistencies.

Version 2.0 replaces the earlier “upload a style template and answer questions as they arise” model with a default-driven controlled process:

1. Inspect the source automatically.
2. Apply documented defaults.
3. Ask only questions that block safe progress.
4. Batch by semantic and accounting boundaries.
5. Preserve source values separately from calculated values.
6. Verify at row, page, batch, section, statement, and workbook levels.
7. Export, reload, rescan, checksum, and package every approved milestone.
8. Perform a logically independent final validation pass.

## What changed from v1

### 1. Questions are now exception-only

The operator must not stop for routine choices. The protocol contains defaults for:

- style and color conventions
- scanned versus born-digital PDFs
- render resolution and escalation
- page rotation
- blank versus zero
- parentheses and negative numbers
- repeated headers
- multi-page tables
- source totals that disagree with detail
- section-heading conflicts
- batch size
- workbook structure
- output naming
- validation and packaging

Only the blocking conditions in `02_AUTONOMY_AND_QUESTION_POLICY.md` justify asking the user.

### 2. Batching is automatic

Batching is mandatory when the source exceeds defined risk or complexity thresholds. Batches are selected by semantic boundaries, not arbitrary equal page counts.

### 3. Source imaging has a formal standard

- Default render: 300 ppi
- Escalation: 400 ppi for small or ambiguous print
- Maximum routine escalation: 600 ppi
- Rendered page image is authoritative
- OCR or extracted text is a locator only
- Rotation, cropping, and image preparation must never alter source content

### 4. Quality assurance is embedded from the beginning

The workbook is designed with checks, controls, and alerts from the outset. Every critical total is tested independently. Final assurance is separate from extraction.

### 5. Provenance is explicit

Every record must be traceable to:

- source file
- source file SHA-256
- PDF page
- printed page, where present
- rendered page image
- batch
- record ID
- source order
- extraction activity
- review activity
- exception or decision record, when applicable

### 6. Delivery packages are preservation-ready

The protocol uses a BagIt-compatible package structure with SHA-256 manifests, release metadata, and a clear authoritative-master designation.

### 7. The A/8407/Add.1 conversion is incorporated as a case study

The successful 105-page conversion exposed the exact failure modes this protocol now handles automatically, including rotated pages, mixed table schemas, hard section boundaries, source arithmetic discrepancies, repeated incorrect headings, narrative-to-statement differences, and table-total inconsistencies.

## Pack contents

| File | Purpose |
|---|---|
| `01_MASTER_ORCHESTRATOR_PROMPT.md` | Reusable master instruction |
| `02_AUTONOMY_AND_QUESTION_POLICY.md` | Defaults and blocking-question rules |
| `03_INTAKE_PREFLIGHT_AND_RISK_SCORING.md` | Automated source assessment |
| `04_BATCHING_AND_BOUNDARY_RULES.md` | Exact batch-selection method |
| `05_SOURCE_RENDERING_AND_TRANSCRIPTION_SOP.md` | Rendering and transcription rules |
| `06_WORKBOOK_ARCHITECTURE_AND_STYLING.md` | Workbook structure and formulas |
| `07_QA_QC_AND_ACCEPTANCE_GATES.md` | Required testing and approval gates |
| `08_EXCEPTION_PROVENANCE_AND_DECISION_CONTROL.md` | Source discrepancy and provenance model |
| `09_VERSIONING_PACKAGING_AND_RECOVERY.md` | Version, checkpoint, and delivery rules |
| `10_EDGE_CASE_CATALOG.md` | Default handling for known difficult cases |
| `11_A8407_CASE_STUDY_AND_LESSONS.md` | Lessons from the completed conversion |
| `12_QUICK_START.md` | Minimal operating instructions |
| `13_RESEARCH_BASIS_AND_STANDARDS.md` | Authoritative research mapped to implementation |
| `14_OPERATOR_CHECKLIST.md` | Compact execution checklist |
| `15_CHANGELOG.md` | Protocol version history |
| `config/defaults.yaml` | Machine-readable operating defaults |
| `config/decision_matrix.yaml` | Automatic decision and escalation rules |
| `templates/*.csv` | Registers and control templates |
| `schemas/protocol_config.schema.json` | Configuration schema |
| `PDF_to_Excel_Protocol_v2_Complete.md` | Consolidated protocol manual |

## Default use

For most projects, upload:

1. the source PDF
2. this protocol pack
3. a prior workbook only when the source is an update

A style workbook is optional. If none is provided, the protocol’s standard workbook architecture and color scheme apply automatically.

## Important limitation

This protocol provides a rigorous, auditable conversion process. It does not claim FADGI, NARA, ISO, regulatory, or legal compliance unless the complete equipment, personnel, validation, and organizational requirements of the applicable standard are independently satisfied.
