# Protocol Changelog

## Version 2.0 — 2026-06-21

Research-integrated rewrite based on the A/8407/Add.1 conversion.

Added:

- blocker-only question policy
- automatic source preflight
- risk scoring and QA tiers
- semantic batching rules
- 300/400/600 ppi rendering ladder
- explicit source-authority hierarchy
- row-type arithmetic
- source/calculated/variance separation
- nine acceptance gates
- independent validation phase
- exception taxonomy
- W3C PROV-inspired provenance
- monotonic versioning and recovery procedure
- BagIt-compatible packaging
- SHA-256 manifests
- final linkage matrix
- publication manifest
- machine-readable defaults and decision matrix
- CSV register templates
- A/8407/Add.1 case study

Removed or changed:

- style template is no longer required
- perfect example is optional
- routine user confirmation is prohibited
- single `.xlsx` delivery is replaced by controlled package delivery for significant projects
- spot checking is no longer sufficient for high-risk financial numeric cells
- generic dashboard/report requirements are replaced by source-appropriate presentation
- final validation is separate from routine batch QC

## Version 1.0

Initial protocol pack focused on style consistency, formula checks, README, Dashboard, Report, and Changelog.

## Version 2.1 — 2026-08-10

Verification-and-research maintenance release.

Fixed:

- `A8407_UNDP1970_MASTER_after_B06_v012.xlsx` check S4-19 (`Checks!C521`) referenced the sheet `Transcription Review`, which had been renamed `Schedule 4 Review`. In Excel this check evaluated to #REF! and silently stopped verifying. Formula repaired to `=COUNTA('Schedule 4 Review'!A4:A19)`; expected/actual value 16 unchanged.
- Package layout restored: `config/`, `schemas/`, and `templates/` subdirectories were flattened in the previous archive, so 12 files failed manifest verification despite being present. Files are back at the paths the manifest declares.
- `SHA256SUMS.txt` regenerated over the corrected layout, now covering workbooks, registers, and this changelog as well as the documentation set.

Added:

- `16_RESEARCH_UPDATE_2026.md` — 2025–2026 research basis update and protocol optimizations O-1 through O-5 (dual-channel extraction, deterministic recalculation gate, confidence-tiered exception routing, page-completeness certification, tooling reference).

Known gaps:

- `Level_10_Forensic_PDF_to_Excel_Practice.pdf` and `Level_10_Practice_Instructor_Key_DO_NOT_OPEN.pdf` are listed in `Level_10_Practice_SHA256SUMS.txt` but are not present in the archive. Their checksums are retained so the files can be verified if recovered.
