# Quick Start

## Normal conversion

Upload:

1. source PDF
2. this protocol pack
3. prior workbook only if updating an existing workbook

Then say:

> Convert this PDF to Excel using Protocol v2. Apply defaults, batch automatically, ask only blocking questions, preserve source discrepancies, and deliver an authoritative cumulative master with audit evidence.

## What happens automatically

The operator will:

- hash the source
- inspect all pages
- create a page register
- score risk
- choose batches
- render pages
- create structured sheets
- build formulas and checks
- preserve exceptions
- create standalone batch files
- create cumulative versions
- reload and verify exports
- create final QA and linkage controls
- package the result with checksums

## You do not need to provide

- a style workbook
- batch sizes
- render resolution
- sheet names
- color rules
- filename conventions
- a list of routine edge-case decisions

The protocol supplies defaults.

## When you may be asked a question

Only when:

- authoritative sources conflict
- a critical field remains unreadable after render escalation
- an update requires a missing compatibility specification
- a requested transformation lacks a governing rule
- security or file corruption blocks access
- legal or financial meaning cannot be represented reversibly
- a required independent signatory is unavailable

## Typical output

- standalone batch workbook
- cumulative master
- completion plan
- audit report
- source-page images
- visual-verification panel
- exception register
- checksums
- controlled ZIP

## Final authority

Use only the file explicitly identified as the authoritative final master.

Earlier batch files are audit history.
