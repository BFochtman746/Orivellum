# A/8407/Add.1 Case Study and Lessons

## Project result

The 105-page United Nations document was converted into a final controlled workbook with:

- 105 approved pages
- 23 approved batches
- Statements I-V
- Schedules 1-7
- 1,136 Schedule 6 project-detail records
- 37 narrative paragraphs
- 11 accepted source issues
- zero unresolved exceptions
- zero final formula errors
- 42 final QA controls
- 23 final linkage controls

## Why batching was essential

The source contained:

- multiple table schemas
- long dense ledgers
- rotated pages
- current-year and prior-year sections
- printed subtotals
- source arithmetic differences
- heading anomalies
- narrative-to-statement differences
- a rounded audit table that did not add exactly

A single-pass build would have made it difficult to isolate whether an error came from transcription, row classification, source arithmetic, section continuity, or formula design.

## Best boundary decisions

### Page 96

Page 96 was isolated because it opened a new current-year Schedule 6 section. This created a clean hard boundary and prevented the section transition from being buried in a larger batch.

### Pages 97-99

These pages continued the current-year records even though pages 97-98 repeated an incorrect prior-year heading. Source order, section continuity, and the absence of a subtotal supported current-year classification.

### Pages 100-103

The closing batch included final current-year detail, the current-year subtotal, projects-not-yet-complete total, completed-project categories, and Schedule 6 grand total.

## Source issues learned

### Schedule 2

Three category-summary differences offset at the grand total.

### Schedule 6

- three row-level printed-excess differences
- one prior-year subtotal difference
- one repeated-heading anomaly

### Narrative

- $163,569 narrative amount versus $163,568 in Statement I
- 6.13% printed versus 6.1551% calculated
- $49,927,000 audit-table total versus $49,927,150 category sum

## Process issues learned

### OCR was not reliable enough

OCR helped locate text but could not safely establish exact numbers, parentheses, or column placement.

### Row-specific formulas were necessary

Schedule 7 deduction rows used a different balance convention from ordinary expense rows.

### Export reload mattered

The workbook process experienced a tool interruption. Approved exports and monotonic versions prevented data loss.

### Visual verification was a real control

Wide schedules required focused ranges and contact sheets. Correct arithmetic alone did not prove readable output.

## Protocol changes caused by the case study

- mandatory batch planning
- semantic boundary rules
- question-suppression defaults
- 300/400/600 ppi render ladder
- explicit row types
- source/calculated/variance separation
- page-level completeness controls
- independent final validation pass
- W3C PROV-inspired provenance
- BagIt-compatible packaging
- SHA-256 manifests
- final linkage matrix
- publication manifest
- explicit acknowledgment of narrative double-keying limitations

## Residual limitation

The narrative was visually reviewed and structurally checked, but it was not independently double-keyed by two human operators and compared character by character. Financial and structural confidence is very high; exact punctuation-level narrative identity should be separately verified when legal publication accuracy requires it.
