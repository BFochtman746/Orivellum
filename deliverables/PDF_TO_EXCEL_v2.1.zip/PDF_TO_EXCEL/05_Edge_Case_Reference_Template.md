# Edge Case Reference Template

## Instructions

Fill in the examples below with real cases from your domain. The AI will pattern-match against these when encountering ambiguous data.

---

## Case 1: Negative Values in Revenue

**PDF Appearance:** `$(85)` in Q4 Services revenue
**Context:** Customer refund processed in December
**Wrong Handling:** Convert to positive $85 or leave as text
**Right Handling:**
- Cell value: -85
- Number format: `$#,##0`
- Fill: `FFC7CE` (red)
- Font: `9C0006` (dark red, bold)
- Footnote: Blue cell below with full explanation

---

## Case 2: N/A in Numeric Column

**PDF Appearance:** `N/A` in Sales Facilities column
**Context:** Facilities cost not tracked for Sales department
**Wrong Handling:** Convert to 0 or leave as text in SUM range
**Right Handling:**
- Cell value: "N/A" (text)
- Fill: `DDEBF7` (blue)
- Font: Italic, gray
- Formula behavior: SUM() skips text automatically
- Note: Do NOT convert to 0

---

## Case 3: Blank vs Zero

**PDF Appearance:** Empty cell in Marketing Other column
**Context:** No spend recorded in that category
**Wrong Handling:** Leave blank or convert to 0 indiscriminately
**Right Handling:**
- If PDF explicitly shows "0": Cell value = 0, yellow fill
- If PDF shows empty/blank: Leave blank, no fill
- If PDF shows "—": Cell value = "—", blue fill

---

## Case 4: Multi-Page Spanned Table

**PDF Appearance:** Production table continues on next page with repeated header
**Context:** 18 months of data across 2 pages
**Wrong Handling:** Include duplicate header rows as data
**Right Handling:**
- Detect repeated header on page 2
- Deduplicate: keep header only on row 1
- Append data rows continuously
- Single FY Grand Total at bottom

---

## Case 5: Scanned Image with No Extractable Text

**PDF Appearance:** Page 8 — "Vendor Payment Backlog (Field Office Submission)" — scanned image
**Context:** Regional field office submitted as image
**Wrong Handling:** Skip the page entirely or fabricate placeholder data
**Right Handling:**
- Create sheet: "Vendor Backlog (Image)"
- Content: "Page submitted as scanned image. Data not machine-readable."
- Do NOT fabricate data
- Note in README: "One page omitted due to image-only submission"

---

## Case 6: Footnote with Restatement

**PDF Appearance:** `¹ Q3 Software revenue of $1,180K reflects originally reported figure... corrected Q3 figure is $1,420K`
**Context:** Post-period review identified deferred revenue
**Wrong Handling:** Ignore footnote or adjust the data
**Right Handling:**
- Preserve original $1,180K in data cell (yellow)
- Add footnote row below table (blue fill, merged)
- State clearly: "This workbook's FY Total is NOT adjusted for this restatement"
- Do NOT change the input data

---

## Case 7: Merged Header Cells

**PDF Appearance:** "Quarter 1" spanning two columns (Actual, Target)
**Context:** Multi-level header in borderless table
**Wrong Handling:** Split into separate cells or flatten to single row
**Right Handling:**
- Reconstruct multi-level header in Excel
- Use merge cells for parent headers
- Preserve child headers below
- Maintain data alignment

---

## Case 8: Currency Symbols and Decimal Precision

**PDF Appearance:** `$2,460.75` or `$(425.5)` or `−12.5%`
**Context:** Mixed currency, parentheses for negatives, Unicode minus
**Wrong Handling:** Strip symbols, convert to plain numbers
**Right Handling:**
- Preserve currency symbol in number format
- Parentheses = negative value in accounting format
- Unicode minus (`−`) = negative, not dash
- Decimal precision must match PDF exactly

---

## Case 9: Checkbox / Selection Marks

**PDF Appearance:** ☑ Approved ☐ Rework Required ☐ Hold for Review
**Context:** Form with interactive checkboxes
**Wrong Handling:** Ignore or extract as text
**Right Handling:**
- Create column: "Approved", "Rework Required", "Hold for Review"
- Values: TRUE/FALSE or "Selected"/"Not Selected"
- Preserve Inspector ID and Disposition Code as separate fields

---

## Case 10: Scientific / Chemical Notation

**PDF Appearance:** H₂O, CO₂, 10³, α-assembly
**Context:** Technical or scientific document
**Wrong Handling:** Convert to plain text (H2O, CO2, 10^3)
**Right Handling:**
- Preserve subscripts and superscripts in cell text
- Use Unicode characters where possible
- For complex formulas, use Mathpix or specialized extraction
- Note in README: "Scientific notation preserved as Unicode"

---

## Case 11: RTL / Arabic / Hebrew Text

**PDF Appearance:** Right-to-left text with embedded numbers
**Context:** International operations report
**Wrong Handling:** Force left-to-left alignment
**Right Handling:**
- Preserve RTL cell alignment
- Numbers should remain LTR within RTL text
- Use Excel's RTL text direction setting
- Test print preview for correct rendering

---

## Case 12: Date Format Variations

**PDF Appearance:** `2026-07-15`, `Jan-2025`, `Q3 2026`, `FY2025`
**Context:** Mixed date representations
**Wrong Handling:** Convert all to one format or leave as text
**Right Handling:**
- Specific dates: Excel date format `YYYY-MM-DD`
- Month labels: Text `MMM-YYYY`
- Quarter labels: Text `Q# YYYY`
- Fiscal year: Text `FYYYYY`
- Do NOT mix formats within the same column

---

## Add Your Own Cases

| Case # | PDF Appearance | Context | Wrong Handling | Right Handling |
|--------|---------------|---------|---------------|----------------|
| 13 | | | | |
| 14 | | | | |
| 15 | | | | |
