# QA, QC, and Acceptance Gates

## Quality dimensions

Every project must measure:

- Accuracy
- Completeness
- Uniqueness
- Consistency
- Validity
- Timeliness/version currency

## Roles

- Analyst: performs extraction and workbook build
- Assurer: reviews methods, source values, formulas, and controls
- Approver: signs off release
- Commissioner/user: defines intended use

When one operator performs multiple roles, use separate passes and disclose the lack of organizational independence.

## Gate G0 — Input integrity

Pass only when:

- source opens
- page count recorded
- SHA-256 recorded
- no unacknowledged source conflict
- prior approved workbook protected
- working copies created

## Gate G1 — Source rendering

Pass only when:

- 100% of page images open and display
- correct page order
- correct orientation
- no clipping
- resolution recorded
- full-page render retained
- ambiguity crops created where needed

## Gate G2 — Transcription

### Financial numeric cells

Tier 3 and Tier 4 projects require direct verification of 100% of critical numeric source cells.

### Narrative

Require:

- 100% paragraph-number and page-boundary verification
- 100% cited monetary values
- 100% footnote markers
- full visual reading pass
- second independent pass for legal or publication-critical text

### Completeness

- every physical page registered
- every structured row has a record ID
- source order has no gaps or duplicates unless documented
- all printed totals, footnotes, and signatures are represented

## Gate G3 — Row calculations

Pass only when:

- every row formula is appropriate to its row type
- all non-exception rows have zero variance
- accepted variances equal documented expected differences
- no unexplained negative or text-in-numeric field remains

## Gate G4 — Page controls

For each page:

- record count
- first record
- last record
- source-order range
- critical numeric totals
- section classification
- continuation state
- exception count

## Gate G5 — Batch controls

Pass only when:

- page controls aggregate to batch totals
- batch opening and closing markers match plan
- carried opening balances reconcile
- closing subtotal reconciles
- all batch checks pass
- key sheets render correctly

## Gate G6 — Cross-sheet controls

Verify:

- statements to schedules
- source detail to statement totals
- narrative amounts to statements
- dashboard and report formulas
- completion metrics
- exception counts
- page-register counts
- batch-register counts

## Gate G7 — Export and reload

After every approved batch:

1. export workbook
2. close or release in-memory state
3. reload exported file
4. scan formulas
5. scan exact `FAIL`
6. inspect key totals
7. render key sheets
8. calculate SHA-256
9. only then mark approved

## Gate G8 — Independent validation

Validation occurs after extraction and routine QC.

Confirm:

- digital package is complete
- records are accurate enough for intended use
- workbook meets specification
- source and output can be traced
- no unprocessed page remains
- no unresolved exception remains
- release evidence is complete

Use a person or pass not responsible for the original QC when possible.

## Gate G9 — Final release

Final release requires:

- 100% page coverage
- 100% approved batches
- zero formula errors
- zero exact failed statuses
- zero unresolved exceptions
- all accepted issues documented
- all linkage controls pass
- publication manifest complete
- authoritative master named
- source PDF retained
- checksums created
- final files reloaded and rescanned

## Sampling policy

Sampling is not permitted for:

- page completeness
- file openability
- final totals
- statement totals
- schedule subtotals
- record IDs
- source order
- accepted exceptions
- critical financial numeric cells in Tier 3 or Tier 4

Sampling may be used only for low-risk repetitive formatting or noncritical text after complete structural verification.

## Failure policy

A batch cannot be approved with an unexplained `FAIL`.

Accepted source differences must display a non-failure status such as:

- PASS — EXPECTED SOURCE VARIANCE
- PASS — ACCEPTED SOURCE SUBTOTAL VARIANCE
- PASS — ACCEPTED HEADING ANOMALY

The exception ID must be present.
