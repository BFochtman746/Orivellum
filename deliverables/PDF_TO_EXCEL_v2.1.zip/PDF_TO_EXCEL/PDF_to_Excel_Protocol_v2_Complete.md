# PDF-to-Excel Controlled Conversion Protocol v2.0 — Complete Manual


---

<!-- Source module: 00_README.md -->

# PDF-to-Excel Controlled Conversion Protocol v2.0

## Purpose

This protocol converts complex PDFs into traceable, formula-driven Excel workbooks while minimizing unnecessary user questions. It is designed for financial reports, historical documents, large schedules, mixed narrative-and-table reports, rotated scans, and documents containing internal inconsistencies.

Version 2.0 replaces the earlier “upload a style template and answer questions as they arise” model with a default-driven controlled process:

1. Inspect the source automatically.
2. Apply documented defaults.
3. Ask only questions that block safe progress.
4. Batch by semantic and accounting boundaries.
5. Preserve source values separately from calculated values.
6. Verify at row, page, batch, section, statement, and workbook levels.
7. Export, reload, rescan, checksum, and package every approved milestone.
8. Perform a logically independent final validation pass.

## What changed from v1

### 1. Questions are now exception-only

The operator must not stop for routine choices. The protocol contains defaults for:

- style and color conventions
- scanned versus born-digital PDFs
- render resolution and escalation
- page rotation
- blank versus zero
- parentheses and negative numbers
- repeated headers
- multi-page tables
- source totals that disagree with detail
- section-heading conflicts
- batch size
- workbook structure
- output naming
- validation and packaging

Only the blocking conditions in `02_AUTONOMY_AND_QUESTION_POLICY.md` justify asking the user.

### 2. Batching is automatic

Batching is mandatory when the source exceeds defined risk or complexity thresholds. Batches are selected by semantic boundaries, not arbitrary equal page counts.

### 3. Source imaging has a formal standard

- Default render: 300 ppi
- Escalation: 400 ppi for small or ambiguous print
- Maximum routine escalation: 600 ppi
- Rendered page image is authoritative
- OCR or extracted text is a locator only
- Rotation, cropping, and image preparation must never alter source content

### 4. Quality assurance is embedded from the beginning

The workbook is designed with checks, controls, and alerts from the outset. Every critical total is tested independently. Final assurance is separate from extraction.

### 5. Provenance is explicit

Every record must be traceable to:

- source file
- source file SHA-256
- PDF page
- printed page, where present
- rendered page image
- batch
- record ID
- source order
- extraction activity
- review activity
- exception or decision record, when applicable

### 6. Delivery packages are preservation-ready

The protocol uses a BagIt-compatible package structure with SHA-256 manifests, release metadata, and a clear authoritative-master designation.

### 7. The A/8407/Add.1 conversion is incorporated as a case study

The successful 105-page conversion exposed the exact failure modes this protocol now handles automatically, including rotated pages, mixed table schemas, hard section boundaries, source arithmetic discrepancies, repeated incorrect headings, narrative-to-statement differences, and table-total inconsistencies.

## Pack contents

| File | Purpose |
|---|---|
| `01_MASTER_ORCHESTRATOR_PROMPT.md` | Reusable master instruction |
| `02_AUTONOMY_AND_QUESTION_POLICY.md` | Defaults and blocking-question rules |
| `03_INTAKE_PREFLIGHT_AND_RISK_SCORING.md` | Automated source assessment |
| `04_BATCHING_AND_BOUNDARY_RULES.md` | Exact batch-selection method |
| `05_SOURCE_RENDERING_AND_TRANSCRIPTION_SOP.md` | Rendering and transcription rules |
| `06_WORKBOOK_ARCHITECTURE_AND_STYLING.md` | Workbook structure and formulas |
| `07_QA_QC_AND_ACCEPTANCE_GATES.md` | Required testing and approval gates |
| `08_EXCEPTION_PROVENANCE_AND_DECISION_CONTROL.md` | Source discrepancy and provenance model |
| `09_VERSIONING_PACKAGING_AND_RECOVERY.md` | Version, checkpoint, and delivery rules |
| `10_EDGE_CASE_CATALOG.md` | Default handling for known difficult cases |
| `11_A8407_CASE_STUDY_AND_LESSONS.md` | Lessons from the completed conversion |
| `12_QUICK_START.md` | Minimal operating instructions |
| `13_RESEARCH_BASIS_AND_STANDARDS.md` | Authoritative research mapped to implementation |
| `14_OPERATOR_CHECKLIST.md` | Compact execution checklist |
| `15_CHANGELOG.md` | Protocol version history |
| `config/defaults.yaml` | Machine-readable operating defaults |
| `config/decision_matrix.yaml` | Automatic decision and escalation rules |
| `templates/*.csv` | Registers and control templates |
| `schemas/protocol_config.schema.json` | Configuration schema |
| `PDF_to_Excel_Protocol_v2_Complete.md` | Consolidated protocol manual |

## Default use

For most projects, upload:

1. the source PDF
2. this protocol pack
3. a prior workbook only when the source is an update

A style workbook is optional. If none is provided, the protocol’s standard workbook architecture and color scheme apply automatically.

## Important limitation

This protocol provides a rigorous, auditable conversion process. It does not claim FADGI, NARA, ISO, regulatory, or legal compliance unless the complete equipment, personnel, validation, and organizational requirements of the applicable standard are independently satisfied.

---

<!-- Source module: 01_MASTER_ORCHESTRATOR_PROMPT.md -->

# Master Orchestrator Prompt — PDF-to-Excel Controlled Conversion v2.0

## Role

You are a forensic document-conversion analyst, spreadsheet engineer, and quality-assurance operator. Convert the supplied PDF into a controlled Excel workbook and delivery package that preserves the source, documents uncertainty, and proves completeness.

## Governing principle

The rendered page image is the authoritative representation of the source. OCR, extracted text, and automated table detection are locators and accelerators only. They may never override a visually verified page.

## Autonomy requirement

Do not ask routine questions. Apply the defaults in this protocol and record the decision. Ask one consolidated question only when a blocking condition in `02_AUTONOMY_AND_QUESTION_POLICY.md` prevents safe progress.

## Mandatory workflow

### Stage 0 — Protect the inputs

1. Confirm every input file opens.
2. Calculate SHA-256 for every source and prior workbook.
3. Copy inputs into a read-only working-source directory.
4. Never overwrite an approved workbook or original source.
5. Create the Project Manifest, Page Register, Batch Plan, Decision Log, and Question Log.

### Stage 1 — Automated preflight

Inspect the full PDF before transcription:

- page count
- physical-page and printed-page mapping
- encryption or corruption
- born-digital, scanned, or hybrid status
- text-layer usefulness
- page orientation
- image quality and small-print risk
- table and narrative regions
- repeated headers
- section starts and ends
- subtotal and grand-total locations
- footnotes, signatures, and appendices
- changes in table schema
- statement-to-schedule dependencies
- likely edge cases

Assign a risk score and select the QA tier.

### Stage 2 — Batch planning

Batch by semantic and accounting boundaries.

Mandatory rules:

- do not split a logical row
- do not split a subtotal from its detail unless the subtotal is intentionally isolated as a closing control
- isolate hard section boundaries when useful
- keep page-level totals with the rows they summarize
- record expected first and last entities
- record expected opening and closing source order
- record expected page counts and section state

Use the limits in `04_BATCHING_AND_BOUNDARY_RULES.md`.

### Stage 3 — Source rendering

1. Render every batch page at 300 ppi.
2. Rotate upright without changing content.
3. Escalate ambiguous pages or crops to 400 ppi.
4. Escalate tiny, degraded, or unresolved print to 600 ppi.
5. Save full-page images and problem-region crops.
6. Confirm every rendered file opens.
7. Preserve page dimensions and page order.
8. Calculate hashes for rendered source images.

### Stage 4 — Data-model design

Before entering data:

1. Identify row types.
2. Identify source columns.
3. Define calculated columns.
4. Define page, batch, section, statement, and workbook controls.
5. Define cross-sheet linkages.
6. Define exception types.
7. Decide which source totals will be preserved separately from calculated totals.
8. Build the workbook skeleton before bulk entry.

### Stage 5 — Controlled transcription

Every data record must include, where applicable:

- Record_ID
- Batch_ID
- PDF_Page
- Printed_Page
- Source_Order
- Record_Type
- Section
- Entity or country
- Full description
- source numeric values
- calculated numeric values
- variances
- status
- review status
- exception ID
- source reference
- reviewer note
- footnote code

Transcription rules:

- preserve blanks as blanks unless the source explicitly reports zero
- store parenthesized numeric values as negative numbers
- preserve source punctuation, labels, and headings
- do not “repair” source totals
- do not invent balancing rows
- do not infer missing amounts without explicit evidence
- preserve repeated or incorrect headings and document classification decisions
- record continuation logic
- distinguish detail, subtotal, deduction, reserve, and grand-total rows

### Stage 6 — Build calculations and controls

All calculated values must be formulas.

Required layers:

1. Row arithmetic
2. Page count and page totals
3. Batch totals
4. Section subtotals
5. Printed-source versus calculated-source controls
6. Statement-to-schedule links
7. Narrative cited-amount links
8. Whole-workbook checks
9. Formula-error scans
10. Exact failure scans

Source totals must remain source values. Calculated totals must remain formulas. Variances must be visible.

### Stage 7 — Batch QA and approval

A batch may be approved only if:

- all source pages are rendered and accounted for
- opening and closing boundaries match the batch plan
- every row has a unique record ID and source order
- every critical numeric source cell is verified
- every row formula passes or has an accepted exception
- page totals pass
- batch totals pass
- expected source variances match documented exceptions
- no unresolved `FAIL` remains
- no formula-error token remains
- key worksheets have been rendered and visually inspected
- the workbook has been exported and reloaded successfully

Create:

- standalone batch workbook
- new cumulative master
- updated completion plan
- batch audit report
- source-page images
- visual-verification image
- checksums
- delivery package

### Stage 8 — Cumulative integration

1. Import only approved batch data.
2. Preserve every prior approved record and exception.
3. Continue source order without gaps or duplicates.
4. update page, batch, version, and exception registers.
5. add or update statement-to-schedule formulas.
6. run backward checks on earlier sections.
7. never overwrite the preceding approved master.

### Stage 9 — Independent validation

After all source extraction is complete:

1. Reload the exported cumulative master in a fresh validation pass.
2. Validate completeness independently from the batch-entry process.
3. Confirm the workbook can serve the same intended informational purpose as the source.
4. Confirm 100% of files open.
5. confirm every source page is represented exactly once.
6. confirm every accepted exception is documented.
7. confirm every statement and schedule equation.
8. confirm all cross-sheet linkages.
9. confirm no failed status or formula error.
10. disclose when no independent human reviewer was available.

### Stage 10 — Final release

Create:

- authoritative final master
- compact final-integration workbook
- completed plan
- final audit report
- publication manifest
- visual-verification panels
- original source copy
- SHA-256 manifests
- BagIt-compatible final package
- final ZIP

The final response must state:

- pages approved
- batches approved
- checks passed
- linkages passed
- accepted issues
- unresolved issues
- formula errors
- authoritative filename
- limitations
- next step, or that the project is complete

## Standard workbook colors

- Yellow `FFF2CC`: source input values
- Green `E2EFDA`: formulas and calculated controls
- Blue `DDEBF7`: metadata, references, provenance, review fields
- Red `FFC7CE` with font `9C0006`: negative values, accepted variances, or failures
- Dark blue `1F4E78`: section and table headers

Color is a navigation aid. It never replaces field names, formulas, or documented status.

## Prohibited actions

- Do not treat OCR as authoritative.
- Do not silently convert blank to zero.
- Do not silently convert dashes to zero.
- Do not hardcode calculated totals.
- Do not overwrite source totals with calculated totals.
- Do not create balancing entries.
- Do not suppress source discrepancies.
- Do not reuse an approved version number.
- Do not overwrite an approved master.
- Do not declare completion from a grand total alone.
- Do not ask the user to decide matters covered by protocol defaults.
- Do not claim independent review when only self-review occurred.

---

<!-- Source module: 02_AUTONOMY_AND_QUESTION_POLICY.md -->

# Autonomy and Question Policy

## Objective

Reduce user interruptions without increasing conversion risk.

The operator applies documented defaults, records the decision, and continues. A question is permitted only when the answer changes the meaning, legal status, structure, or safe recoverability of the output and cannot be resolved from the source or supplied files.

## Decision hierarchy

Use this order:

1. Explicit user instruction
2. Existing approved workbook or style specification
3. Source-document evidence
4. This protocol’s defaults
5. Conservative reversible decision with a Decision Log entry
6. One blocking question

## Blocking conditions

Ask the user only when at least one condition below is true.

### BQ-01 — Competing authoritative sources

Two or more source files contain conflicting content and there is no reliable indication which one governs.

Default question:

> I found conflicting source versions. I can proceed with [file A] as the default because [evidence], while preserving [file B] as a reference. Confirm A, choose B, or tell me the precedence rule.

### BQ-02 — Required compatibility target is unknown

The user explicitly requests an update to an existing workbook or downstream system, but the prior workbook, schema, required column order, or import specification is missing.

Do not ask when building a new workbook from scratch.

### BQ-03 — Source is unreadable after escalation

A critical field remains unreadable after:

- full-page render at 300 ppi
- upright orientation
- crop at 400 ppi
- crop at 600 ppi
- comparison with the PDF text layer
- comparison with neighboring rows and totals

Ask one question containing all unresolved fields and the best candidate reading.

### BQ-04 — Transformation is requested but undefined

The user asks for currency conversion, translation, reclassification, restatement, or normalization without specifying the governing date, rate, language, or accounting rule.

No question is needed for faithful source transcription.

### BQ-05 — Security or access prevents work

The source is password-protected, corrupt, incomplete, or inaccessible.

### BQ-06 — Material interpretation has no reversible default

A choice would change financial meaning or legal interpretation and cannot be represented as separate source and calculated values.

### BQ-07 — Final approval requires an unavailable human role

The user requires regulatory, legal, certified, or independently signed validation. The operator may prepare the evidence but must ask who will perform or authorize the required sign-off.

## Non-blocking matters that must not cause a question

| Situation | Automatic action |
|---|---|
| No style template | Apply protocol standard workbook architecture and colors |
| No prior workbook | Create a new controlled workbook |
| Scanned PDF | Render and visually transcribe |
| Hybrid PDF | Use text layer as locator, image as authority |
| Rotated page | Rotate rendered derivative upright |
| Blank numeric cell | Preserve blank |
| Explicit zero | Store numeric zero |
| Parenthesized number | Store negative numeric value |
| Dash or em dash | Preserve as source marker; do not assume zero |
| Repeated table header | Deduplicate in structured data but preserve page evidence |
| Continued row or entity | Continue only when visually supported |
| Printed total disagrees with detail | Preserve both and create an exception |
| Heading conflicts with section continuity | Classify by strongest structural evidence and preserve the heading anomaly |
| Page contains final subtotal | Keep with closing batch or isolate as a control page |
| PDF is large | Batch automatically |
| User does not name output files | Use protocol naming convention |
| User does not specify render resolution | Use 300 ppi default |
| User does not request macros | Use no macros or VBA |
| User does not specify formula style | Use transparent native Excel formulas |
| User does not specify delivery package | Create standard controlled package |

## Consolidated-question rule

When blocking questions exist:

1. Complete all non-blocked work first.
2. Ask one message, not multiple sequential questions.
3. Group unresolved items by page and field.
4. State the proposed default.
5. Explain the consequence of each option.
6. Continue immediately after the answer.

## Decision Log

Every non-obvious automatic decision must record:

- Decision_ID
- date and time
- batch
- page
- issue
- options considered
- selected decision
- evidence
- reversibility
- whether user input was required
- reviewer

---

<!-- Source module: 03_INTAKE_PREFLIGHT_AND_RISK_SCORING.md -->

# Intake, Preflight, and Risk Scoring

## Required inputs

Minimum:

- source PDF

Recommended:

- prior approved workbook, if updating
- domain glossary
- known page or total expectations
- desired output filename

Optional:

- style template
- perfect example
- downstream import schema

The absence of optional material must not stop the conversion.

## Preflight output

Before transcription, create a Project Manifest and Page Register containing:

- project ID
- source filename
- source SHA-256
- file size
- page count
- encryption status
- text-layer status
- source type: born-digital, scanned, hybrid
- page dimensions
- orientation
- printed-page mapping
- section classification
- table schema
- narrative presence
- footnote presence
- total/subtotal presence
- risk score
- planned batch
- render status
- review status

## Source assessment

### File integrity

Check:

- file exists
- file size is non-zero
- PDF opens
- page count is readable
- no unexpected truncation
- password/encryption status
- SHA-256 captured

### Page assessment

For every page, identify:

- portrait, landscape, rotated, or mixed
- printed page number
- table, narrative, image, signature, or mixed
- new section, continuation, subtotal, grand total, or appendix
- text-layer usefulness
- small-print risk
- low-contrast risk
- skew or distortion
- multi-column reading order
- continued entity or row
- repeated header
- footnotes
- source anomalies

## Risk scoring

Score each dimension from 0 to 3.

| Dimension | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| Image quality | clear born-digital | minor scan issues | low contrast or rotation | degraded or tiny print |
| Table density | no table | simple table | dense table | highly dense ledger |
| Schema stability | one stable schema | minor changes | multiple schemas | frequent schema changes |
| Financial criticality | descriptive | noncritical amounts | material totals | statements or audited totals |
| Boundary complexity | none | repeated headers | section changes | ambiguous section continuity |
| Cross-sheet dependency | none | one link | several links | statement/schedule network |
| Source inconsistency | none | rounding | row variance | subtotal or heading conflict |
| Narrative complexity | none | simple paragraphs | footnotes/tables | legal/audit narrative |

### Risk class

- 0–5: Low
- 6–11: Moderate
- 12–17: High
- 18–24: Critical

Static historical financial reports default to at least **High** even when the visual score is lower.

## QA tier

| Risk class | QA tier | Required assurance |
|---|---|---|
| Low | Tier 1 | complete page register, all totals, 10 source spot checks |
| Moderate | Tier 2 | 100% key numeric cells, row formulas, page totals, export reload |
| High | Tier 3 | 100% numeric cells, page/batch/section controls, cross-sheet checks, independent validation pass |
| Critical | Tier 4 | Tier 3 plus smaller batches, dual-pass transcription, extensive crops, formal sign-off evidence |

Financial statements, schedules, audited totals, and legal tables must use Tier 3 or Tier 4.

## Preflight acceptance gate

Do not begin bulk transcription until:

- source integrity passes
- all pages are registered
- source type is classified
- render plan is established
- batch plan is established
- risk and QA tier are recorded
- known cross-sheet relationships are mapped
- unresolved blockers are consolidated

---

<!-- Source module: 04_BATCHING_AND_BOUNDARY_RULES.md -->

# Batching and Boundary Rules

## Why batching is mandatory

Batching isolates errors, provides recovery checkpoints, and allows page-level reconciliation before the cumulative master is changed.

Batching is mandatory when any of these is true:

- more than 10 source pages
- more than 150 structured records
- more than one table schema
- more than one financial statement or schedule
- scanned or rotated pages with dense numeric content
- section totals occur before the end of the source
- source order spans multiple pages
- statement-to-schedule linkages exist
- known or suspected source inconsistencies exist

## Boundary priority

Choose boundaries in this order:

1. End of statement or schedule
2. Printed subtotal or grand total
3. New accounting section
4. Hard heading change
5. New table schema
6. End of entity group
7. Page-count or record-count limit

Do not create equal-size batches when a semantic boundary is nearby.

## Default batch sizes

| Source type | Default batch |
|---|---|
| Dense ledger or project schedule | 3–5 pages or 100–150 records |
| Moderate financial table | 5–8 pages |
| Simple short schedule | entire schedule |
| Boundary or closing-total page | 1–3 pages |
| Narrative with numbered paragraphs | 5–10 pages, preserving section sequence |
| Mixed narrative and tables | split by document part |
| Final integration | separate zero-source batch |

Use the smaller limit when risk is High or Critical.

## Mandatory boundary controls

Every batch plan must state:

- Batch_ID
- PDF page range
- printed page range
- section
- expected first entity or paragraph
- expected last entity or paragraph
- opening source order
- expected closing source order
- expected row count, if known
- opening balance or carried subtotal
- expected closing subtotal
- source anomalies
- linked statement or schedule
- next batch

## Special boundary rules

### New section begins mid-document

Prefer a new batch at the first page of the new section.

### Page contains both detail and final totals

Keep the page in the closing batch. Do not move printed totals into a separate workbook without the detail they close unless the page is explicitly treated as a source-control page.

### Repeated or incorrect heading

Do not let the heading alone determine the batch. Use:

- preceding section
- following section
- source-order continuity
- subtotal boundaries
- printed page sequence
- table schema
- narrative cross-reference

Record the heading as an anomaly.

### Row continues across pages

Keep both page fragments in the same batch whenever feasible. If not feasible, record a continuation key and prohibit duplicate counting.

### Narrative sequence

Never split in a way that loses paragraph numbering, footnote linkage, or section heading context.

## Batch state machine

A batch moves through:

1. Planned
2. Rendered
3. Extracted
4. Self-reviewed
5. Reconciled
6. Exported
7. Reload-verified
8. Approved
9. Integrated

A batch cannot skip a state.

## Batch approval conditions

- all planned pages present
- page images open
- first and last boundary markers match
- source order continuous
- no duplicate record IDs
- expected page counts pass
- expected batch totals pass
- all failures resolved or accepted
- audit report written
- standalone and cumulative files exported
- exports reloaded
- checksums produced

---

<!-- Source module: 05_SOURCE_RENDERING_AND_TRANSCRIPTION_SOP.md -->

# Source Rendering and Transcription SOP

## Authority hierarchy

1. Rendered page image
2. Original PDF viewed directly
3. Neighboring page and section structure
4. Printed subtotals and arithmetic controls
5. PDF text layer
6. OCR output

A lower source cannot override a higher source without a documented reason.

## Rendering standard

### Default

Render modern textual pages at 300 ppi.

### Escalation

Use 400 ppi when:

- print is small
- digits touch rules or gridlines
- punctuation or parentheses are unclear
- footnotes are dense
- OCR and visual readings conflict

Use 600 ppi when:

- a critical digit remains unresolved at 400 ppi
- the scan is degraded
- a tiny crop is required
- microprint or faint marks materially affect interpretation

### Orientation

- save the original render
- create a separate upright derivative
- never crop away source content in the archival full-page render
- create separate crops for detailed review
- do not enhance, erase, redraw, or alter source marks
- document any contrast or sharpening used for a review derivative

## Page-render checklist

For every page:

- file opens
- correct page number
- correct orientation
- complete page boundary visible
- no clipping
- no accidental rescaling that changes source proportions
- readable at 100% zoom
- printed page number identified
- hash recorded
- page registered

## Transcription order

1. Page and section metadata
2. Row identity and source order
3. Labels and descriptions
4. Numeric source values
5. Footnotes and markers
6. Row type
7. Calculated formulas
8. Variance and status
9. reviewer notes
10. exception or decision ID

## Numeric rules

### Blank

A blank is stored as blank.

Do not convert blank to zero unless:

- the source explicitly states zero, or
- a governing schema defines blank as zero and that rule is documented.

### Zero

Store explicit zero as numeric zero.

### Parentheses

In a numeric context, `(123)` is stored as `-123`, unless the source clearly uses parentheses for another meaning.

### Dash and em dash

Preserve as a source marker or blank-state code. Do not assume zero.

### Currency symbols and commas

Store numeric value without formatting characters and apply an Excel number format.

### Percentages

Store as a numeric percentage or explicit percentage point according to the source. Preserve the printed percentage even when it does not equal the displayed numerator and denominator; calculate the independent ratio separately.

### Rounding

Do not force rounded detail to equal rounded totals. Preserve displayed rows and displayed totals, then record the difference.

## Text rules

- preserve names, titles, punctuation, and capitalization
- preserve paragraph numbering
- preserve footnote markers
- retain page and section context
- do not modernize historical spelling
- do not paraphrase source narrative in the transcription sheet
- summaries belong in a Report sheet, not in source-text fields

## Multi-page table rules

- remove repeated header rows from structured detail
- preserve the repeated header in page evidence
- continue an entity only when supported visually
- use source order to prevent duplicates
- store page number on every row
- identify split rows explicitly
- do not combine source rows merely because descriptions are similar

## Source total rule

When a printed total disagrees with verified detail:

- retain the printed total as a source value
- calculate detail independently
- calculate variance
- investigate transcription first
- create an exception only after rechecking
- never add a balancing row

---

<!-- Source module: 06_WORKBOOK_ARCHITECTURE_AND_STYLING.md -->

# Workbook Architecture and Styling

## Standard sheets

Every significant project should contain:

1. README
2. Workflow
3. Page Register
4. Batch Control
5. Data Dictionary
6. Exceptions
7. Checks
8. Reconciliation
9. Changelog
10. Data or schedule sheets
11. Narrative sheets, where present
12. Dashboard
13. Report

Large or critical projects should also contain:

14. Decision Log
15. Question Log
16. Linkage Matrix
17. Final QA
18. Publication Manifest
19. Completion Summary

## Separation of concerns

### Source layer

Exact source values and text.

### Calculation layer

Formulas, normalized values, and independent arithmetic.

### Control layer

Checks, reconciliation, exceptions, status, and provenance.

### Presentation layer

Dashboard, report, and reader-facing summaries.

Do not mix source input and formula output in the same field.

## Color convention

| Color | Hex | Meaning |
|---|---|---|
| Yellow | `FFF2CC` | Source values or user-editable inputs |
| Green | `E2EFDA` | Formula output and calculated controls |
| Blue | `DDEBF7` | Metadata, provenance, references, review fields |
| Red | `FFC7CE` | Negative values, accepted variances, failures |
| Dark blue | `1F4E78` | Headers and section bars |
| Light gray | `F2F2F2` | Narrative background and neutral labels |

A status field is still required. Color alone is not a control.

## Standard record fields

- Record_ID
- Batch_ID
- PDF_Page
- Printed_Page
- Source_Order
- Record_Type
- Section
- Entity
- Description
- source columns
- calculated columns
- variance columns
- Row_Check
- Review_Status
- Exception_ID
- Decision_ID
- Source_Reference
- Source_File_SHA256
- Rendered_Page_SHA256
- Reviewer_Note
- Footnote_Code

## Record types

At minimum:

- Detail
- Continued detail
- Subtotal
- Deduction
- Reserve
- Grand total
- Narrative
- Footnote
- Source control
- Calculated control
- Exception
- Signature

## Formula rules

- all derived values are formulas
- no hardcoded subtotals
- no circular references
- formulas must exclude their own total row
- use explicit row ranges
- use structured tables when they improve traceability
- avoid volatile formulas unless necessary
- do not hide error-handling that masks bad inputs
- cross-sheet totals should reference the supporting schedule
- source totals should not be replaced by formulas
- use a separate calculated-total field

## Required check columns

For financial rows:

- Calculated_Total
- Calculated_Balance or Calculated_Excess
- Variance
- Row_Check

For source subtotals:

- Printed_Source_Total
- Calculated_Detail_Total
- Difference
- Expected_Difference
- Status
- Exception_ID

## Cross-sheet design

Build a Linkage Matrix with:

- Link_ID
- relationship
- left control
- left value
- right control
- right value
- difference
- expected difference
- status
- evidence
- notes

Replace duplicated hardcoded statement values with formulas to supporting schedules when the relationship is clear and the source design supports it.

## Formatting

- freeze headers
- wrap long descriptions
- set readable column widths
- use consistent number formats
- use red formatting for negative values
- landscape for wide schedules
- fit to width
- repeat header row on print pages when supported
- show page, batch, and section in titles
- render key views for visual inspection

## Macro policy

Default: no VBA, macros, or external links.

Use macros only when the user explicitly authorizes them and the downstream environment permits them.

---

<!-- Source module: 07_QA_QC_AND_ACCEPTANCE_GATES.md -->

# QA, QC, and Acceptance Gates

## Quality dimensions

Every project must measure:

- Accuracy
- Completeness
- Uniqueness
- Consistency
- Validity
- Timeliness/version currency

## Roles

- Analyst: performs extraction and workbook build
- Assurer: reviews methods, source values, formulas, and controls
- Approver: signs off release
- Commissioner/user: defines intended use

When one operator performs multiple roles, use separate passes and disclose the lack of organizational independence.

## Gate G0 — Input integrity

Pass only when:

- source opens
- page count recorded
- SHA-256 recorded
- no unacknowledged source conflict
- prior approved workbook protected
- working copies created

## Gate G1 — Source rendering

Pass only when:

- 100% of page images open and display
- correct page order
- correct orientation
- no clipping
- resolution recorded
- full-page render retained
- ambiguity crops created where needed

## Gate G2 — Transcription

### Financial numeric cells

Tier 3 and Tier 4 projects require direct verification of 100% of critical numeric source cells.

### Narrative

Require:

- 100% paragraph-number and page-boundary verification
- 100% cited monetary values
- 100% footnote markers
- full visual reading pass
- second independent pass for legal or publication-critical text

### Completeness

- every physical page registered
- every structured row has a record ID
- source order has no gaps or duplicates unless documented
- all printed totals, footnotes, and signatures are represented

## Gate G3 — Row calculations

Pass only when:

- every row formula is appropriate to its row type
- all non-exception rows have zero variance
- accepted variances equal documented expected differences
- no unexplained negative or text-in-numeric field remains

## Gate G4 — Page controls

For each page:

- record count
- first record
- last record
- source-order range
- critical numeric totals
- section classification
- continuation state
- exception count

## Gate G5 — Batch controls

Pass only when:

- page controls aggregate to batch totals
- batch opening and closing markers match plan
- carried opening balances reconcile
- closing subtotal reconciles
- all batch checks pass
- key sheets render correctly

## Gate G6 — Cross-sheet controls

Verify:

- statements to schedules
- source detail to statement totals
- narrative amounts to statements
- dashboard and report formulas
- completion metrics
- exception counts
- page-register counts
- batch-register counts

## Gate G7 — Export and reload

After every approved batch:

1. export workbook
2. close or release in-memory state
3. reload exported file
4. scan formulas
5. scan exact `FAIL`
6. inspect key totals
7. render key sheets
8. calculate SHA-256
9. only then mark approved

## Gate G8 — Independent validation

Validation occurs after extraction and routine QC.

Confirm:

- digital package is complete
- records are accurate enough for intended use
- workbook meets specification
- source and output can be traced
- no unprocessed page remains
- no unresolved exception remains
- release evidence is complete

Use a person or pass not responsible for the original QC when possible.

## Gate G9 — Final release

Final release requires:

- 100% page coverage
- 100% approved batches
- zero formula errors
- zero exact failed statuses
- zero unresolved exceptions
- all accepted issues documented
- all linkage controls pass
- publication manifest complete
- authoritative master named
- source PDF retained
- checksums created
- final files reloaded and rescanned

## Sampling policy

Sampling is not permitted for:

- page completeness
- file openability
- final totals
- statement totals
- schedule subtotals
- record IDs
- source order
- accepted exceptions
- critical financial numeric cells in Tier 3 or Tier 4

Sampling may be used only for low-risk repetitive formatting or noncritical text after complete structural verification.

## Failure policy

A batch cannot be approved with an unexplained `FAIL`.

Accepted source differences must display a non-failure status such as:

- PASS — EXPECTED SOURCE VARIANCE
- PASS — ACCEPTED SOURCE SUBTOTAL VARIANCE
- PASS — ACCEPTED HEADING ANOMALY

The exception ID must be present.

---

<!-- Source module: 08_EXCEPTION_PROVENANCE_AND_DECISION_CONTROL.md -->

# Exception, Provenance, and Decision Control

## Principle

Source discrepancies are evidence. They are not inconveniences to erase.

## Exception taxonomy

| Code | Type |
|---|---|
| ARITH | Source arithmetic variance |
| ROW | Row-level source variance |
| SUBTOTAL | Source subtotal variance |
| TOTAL | Source grand-total variance |
| ROUND | Rounding variance |
| HEADING | Heading or section anomaly |
| NARRATIVE | Narrative-to-statement variance |
| PERCENT | Percentage variance |
| TABLE | Displayed table-total variance |
| OCR | OCR or text-layer conflict |
| IMAGE | Source-image ambiguity |
| CLASS | Classification ambiguity |
| MISSING | Missing or unreadable source value |
| LINK | Cross-sheet linkage difference |
| FORMAT | Source formatting ambiguity |

## Exception ID

Use:

`EXC-<PROJECT>-<BATCH>-<SEQUENCE>`

Example:

`EXC-A8407-B07-006`

## Exception Register fields

- Exception_ID
- Project_ID
- Batch_ID
- PDF_Page
- Printed_Page
- Record_ID
- Source_Order
- Exception_Type
- Description
- Printed_Source_Value
- Calculated_or_Linked_Value
- Difference
- Evidence
- Investigation_Steps
- Disposition
- Expected_Difference
- Status
- Reviewer
- Approved_Version
- Notes

## Investigation before acceptance

1. Re-render the page.
2. Inspect at 100% and enlarged crop.
3. Compare the original PDF view.
4. Check text layer as a locator.
5. Verify neighboring rows.
6. Recalculate independently.
7. Check page and batch totals.
8. Confirm no duplicate or missing row.
9. Confirm row type.
10. Only then accept a source discrepancy.

## Dispositions

- Corrected transcription error
- Accepted source arithmetic variance
- Accepted source subtotal variance
- Accepted source heading anomaly
- Accepted source narrative variance
- Accepted source percentage variance
- Accepted source table-total variance
- Unresolved — user input required
- Unreadable — preserved as missing
- Out of scope

## Decision Log

Use for non-error judgments such as:

- section classification
- row continuation
- batch boundary
- blank versus source marker
- linkage design
- formula convention
- print-layout decision

Decision records must remain reversible.

## Provenance model

Use a practical W3C PROV-inspired model.

### Entities

- original PDF
- PDF page
- rendered page image
- crop image
- source row
- batch workbook
- cumulative master
- audit report
- final package

### Activities

- rendering
- rotation
- transcription
- calculation
- review
- reconciliation
- export
- validation
- packaging

### Agents

- analyst
- assurer
- approver
- software/tool version

## Minimum provenance fields

- Source_File
- Source_File_SHA256
- PDF_Page
- Printed_Page
- Rendered_Image
- Rendered_Image_SHA256
- Record_ID
- Batch_ID
- Source_Order
- Extracted_By
- Extracted_At
- Reviewed_By
- Reviewed_At
- Derived_From
- Exception_ID
- Decision_ID
- Workbook_Version

## Question Log

Every user question must record:

- Question_ID
- blocking condition
- page or file
- question
- proposed default
- options
- answer
- effect on output
- date

---

<!-- Source module: 09_VERSIONING_PACKAGING_AND_RECOVERY.md -->

# Versioning, Packaging, and Recovery

## Version rule

Never overwrite an approved master.

Use monotonic versions:

- batch workbook: `PROJECT_Bxx_DESCRIPTION_v01.xlsx`
- cumulative master: `PROJECT_MASTER_after_Bxx_vNNN.xlsx`
- final master: `PROJECT_FINAL_MASTER_vNNN.xlsx`

## Checkpoint rule

Create a durable checkpoint after:

- preflight and batch plan
- every approved batch
- every corrected approved batch
- final extraction
- final integration

## Export verification

After export:

1. confirm file exists
2. confirm non-zero size
3. reload workbook
4. inspect key ranges
5. rescan formula errors
6. rescan exact failure values
7. render key sheets
8. calculate SHA-256
9. record export timestamp and tool version

## Recovery procedure

If the workbook process, kernel, or tool fails:

1. stop writing
2. preserve logs
3. identify latest approved exported master
4. verify its SHA-256
5. reload that version
6. compare Batch Control and Changelog
7. resume only the unapproved batch
8. do not reconstruct approved work from memory
9. document the interruption in the Changelog

## Delivery package

Use this BagIt-compatible structure:

```text
PROJECT_FINAL_Delivery/
├── bagit.txt
├── bag-info.txt
├── manifest-sha256.txt
├── tagmanifest-sha256.txt
└── data/
    ├── source/
    │   └── original_source.pdf
    ├── workbooks/
    │   ├── PROJECT_FINAL_MASTER_vNNN.xlsx
    │   ├── PROJECT_Final_Integration_v01.xlsx
    │   └── PROJECT_Completion_Plan_FINAL.xlsx
    ├── audit/
    │   ├── FINAL_Audit_Report.md
    │   ├── Publication_Manifest.md
    │   └── README.md
    └── renders/
        ├── controls_verification.png
        ├── statements_verification.png
        └── schedules_verification.png
```

A conventional ZIP may contain this structure.

## Bag metadata

`bag-info.txt` should include:

- Source-Organization
- Organization-Address, if applicable
- External-Identifier
- Bagging-Date
- Bag-Software-Agent
- Payload-Oxum
- Project-ID
- Final-Master
- Source-SHA256
- Page-Count
- Approved-Batches
- Accepted-Exceptions
- Validation-Status

## SHA-256

Use SHA-256 for:

- original source
- every authoritative workbook
- audit report
- publication manifest
- final render panels
- final package payload

Do not use the hash as proof of correctness. It proves that a file has not changed since the digest was generated.

## Authoritative-file rule

The final README and manifest must identify exactly one authoritative master.

Historical batch workbooks remain audit evidence and must not be presented as equivalent final versions.

---

<!-- Source module: 10_EDGE_CASE_CATALOG.md -->

# Edge Case Catalog

## EC-001 — Blank numeric cell

**Default:** preserve blank.

**Do not:** convert to zero.

## EC-002 — Explicit zero

**Default:** numeric zero with source-input formatting.

## EC-003 — Parenthesized amount

**Default:** negative numeric value.

**Check:** row-type arithmetic may use a different balance direction.

## EC-004 — Dash or em dash

**Default:** preserve as a source marker or blank code.

**Do not:** assume zero.

## EC-005 — Repeated page header

**Default:** omit from structured detail, preserve in page evidence.

## EC-006 — Repeated incorrect heading

**Default:** classify using section continuity, source order, subtotal boundaries, and neighboring pages. Preserve heading anomaly.

## EC-007 — Row split across pages

**Default:** one logical record with both source pages or an explicit continuation record.

## EC-008 — Country or entity continued from prior page

**Default:** continue only when visual layout and sequence support it.

## EC-009 — Source total disagrees with detail

**Default:** preserve both; calculate variance; investigate; create exception if verified.

## EC-010 — Source row arithmetic disagrees

**Default:** source fields remain unchanged; calculated fields show independent arithmetic; record expected variance.

## EC-011 — Rounded category rows do not equal rounded total

**Default:** preserve displayed rows and total separately.

## EC-012 — Percentage does not equal displayed numerator and denominator

**Default:** preserve printed percentage and calculate independent ratio.

## EC-013 — Narrative amount conflicts with financial statement

**Default:** preserve both and cross-reference with an exception.

## EC-014 — Scanned page with no useful text layer

**Default:** visual transcription from rendered page.

## EC-015 — OCR digit conflict

**Default:** page image wins.

## EC-016 — Small print

**Default:** 400 ppi crop; escalate to 600 ppi if unresolved.

## EC-017 — Rotated page

**Default:** retain original render and create upright derivative.

## EC-018 — Skewed scan

**Default:** create a deskewed review derivative without modifying the original render.

## EC-019 — Table schema changes mid-document

**Default:** new batch or new table model at the change.

## EC-020 — Page contains detail and grand total

**Default:** keep in closing batch.

## EC-021 — Multiple subtotal levels

**Default:** explicit Record_Type and separate formulas for each level.

## EC-022 — Deduction row

**Default:** row-specific formula based on accounting meaning; do not copy ordinary expense formula blindly.

## EC-023 — Reserve row

**Default:** preserve source sign and define formula convention explicitly.

## EC-024 — Footnote affects a number

**Default:** link footnote code to the affected record and preserve full text.

## EC-025 — Footnote marker appears as a digit

**Default:** use page layout and superscript position; do not treat as amount.

## EC-026 — Unreadable critical digit

**Default:** exhaust render escalation and arithmetic evidence, then ask one blocking question.

## EC-027 — Missing style template

**Default:** protocol standard style.

## EC-028 — Missing prior workbook

**Default:** create new workbook unless the user explicitly requested a compatible update.

## EC-029 — Formula passes but source is incomplete

**Default:** fail completeness. Arithmetic agreement cannot prove page completeness.

## EC-030 — Grand total passes but page total fails

**Default:** batch remains unapproved.

## EC-031 — Exported workbook differs from in-memory workbook

**Default:** exported file is not approved; repair and re-export.

## EC-032 — Tool crash

**Default:** reload latest approved export and resume unapproved work only.

## EC-033 — Duplicate record ID

**Default:** fail uniqueness; investigate before approval.

## EC-034 — Source-order gap

**Default:** fail completeness unless a documented non-record page explains the gap.

## EC-035 — Narrative punctuation uncertainty

**Default:** preserve best visual reading and note uncertainty; for publication-critical text, require second pass.

## EC-036 — Handwritten annotation

**Default:** preserve as an annotation record; do not merge into printed text unless clearly intended.

## EC-037 — Hidden or filtered workbook rows

**Default:** avoid hidden source data; all control-relevant records must be visible or documented.

## EC-038 — External workbook link

**Default:** replace with internal controlled values or formulas unless explicitly required.

## EC-039 — Formula error masked by IFERROR

**Default:** do not use IFERROR to conceal an unexpected error.

## EC-040 — Multiple source versions

**Default:** apply BQ-01 and ask one precedence question.

---

<!-- Source module: 11_A8407_CASE_STUDY_AND_LESSONS.md -->

# A/8407/Add.1 Case Study and Lessons

## Project result

The 105-page United Nations document was converted into a final controlled workbook with:

- 105 approved pages
- 23 approved batches
- Statements I-V
- Schedules 1-7
- 1,136 Schedule 6 project-detail records
- 37 narrative paragraphs
- 11 accepted source issues
- zero unresolved exceptions
- zero final formula errors
- 42 final QA controls
- 23 final linkage controls

## Why batching was essential

The source contained:

- multiple table schemas
- long dense ledgers
- rotated pages
- current-year and prior-year sections
- printed subtotals
- source arithmetic differences
- heading anomalies
- narrative-to-statement differences
- a rounded audit table that did not add exactly

A single-pass build would have made it difficult to isolate whether an error came from transcription, row classification, source arithmetic, section continuity, or formula design.

## Best boundary decisions

### Page 96

Page 96 was isolated because it opened a new current-year Schedule 6 section. This created a clean hard boundary and prevented the section transition from being buried in a larger batch.

### Pages 97-99

These pages continued the current-year records even though pages 97-98 repeated an incorrect prior-year heading. Source order, section continuity, and the absence of a subtotal supported current-year classification.

### Pages 100-103

The closing batch included final current-year detail, the current-year subtotal, projects-not-yet-complete total, completed-project categories, and Schedule 6 grand total.

## Source issues learned

### Schedule 2

Three category-summary differences offset at the grand total.

### Schedule 6

- three row-level printed-excess differences
- one prior-year subtotal difference
- one repeated-heading anomaly

### Narrative

- $163,569 narrative amount versus $163,568 in Statement I
- 6.13% printed versus 6.1551% calculated
- $49,927,000 audit-table total versus $49,927,150 category sum

## Process issues learned

### OCR was not reliable enough

OCR helped locate text but could not safely establish exact numbers, parentheses, or column placement.

### Row-specific formulas were necessary

Schedule 7 deduction rows used a different balance convention from ordinary expense rows.

### Export reload mattered

The workbook process experienced a tool interruption. Approved exports and monotonic versions prevented data loss.

### Visual verification was a real control

Wide schedules required focused ranges and contact sheets. Correct arithmetic alone did not prove readable output.

## Protocol changes caused by the case study

- mandatory batch planning
- semantic boundary rules
- question-suppression defaults
- 300/400/600 ppi render ladder
- explicit row types
- source/calculated/variance separation
- page-level completeness controls
- independent final validation pass
- W3C PROV-inspired provenance
- BagIt-compatible packaging
- SHA-256 manifests
- final linkage matrix
- publication manifest
- explicit acknowledgment of narrative double-keying limitations

## Residual limitation

The narrative was visually reviewed and structurally checked, but it was not independently double-keyed by two human operators and compared character by character. Financial and structural confidence is very high; exact punctuation-level narrative identity should be separately verified when legal publication accuracy requires it.

---

<!-- Source module: 12_QUICK_START.md -->

# Quick Start

## Normal conversion

Upload:

1. source PDF
2. this protocol pack
3. prior workbook only if updating an existing workbook

Then say:

> Convert this PDF to Excel using Protocol v2. Apply defaults, batch automatically, ask only blocking questions, preserve source discrepancies, and deliver an authoritative cumulative master with audit evidence.

## What happens automatically

The operator will:

- hash the source
- inspect all pages
- create a page register
- score risk
- choose batches
- render pages
- create structured sheets
- build formulas and checks
- preserve exceptions
- create standalone batch files
- create cumulative versions
- reload and verify exports
- create final QA and linkage controls
- package the result with checksums

## You do not need to provide

- a style workbook
- batch sizes
- render resolution
- sheet names
- color rules
- filename conventions
- a list of routine edge-case decisions

The protocol supplies defaults.

## When you may be asked a question

Only when:

- authoritative sources conflict
- a critical field remains unreadable after render escalation
- an update requires a missing compatibility specification
- a requested transformation lacks a governing rule
- security or file corruption blocks access
- legal or financial meaning cannot be represented reversibly
- a required independent signatory is unavailable

## Typical output

- standalone batch workbook
- cumulative master
- completion plan
- audit report
- source-page images
- visual-verification panel
- exception register
- checksums
- controlled ZIP

## Final authority

Use only the file explicitly identified as the authoritative final master.

Earlier batch files are audit history.

---

<!-- Source module: 13_RESEARCH_BASIS_AND_STANDARDS.md -->

# Research Basis and Standards Mapping

## Purpose

Version 2.0 incorporates current authoritative guidance on digitization, analytical quality assurance, spreadsheet engineering, provenance, and digital packaging.

The protocol adapts these principles to PDF-to-Excel conversion. It does not claim formal regulatory compliance.

## 1. Federal Agencies Digital Guidelines Initiative — FADGI

Source:

- *Technical Guidelines for Digitizing Cultural Heritage Materials, Third Edition*, 2023
- https://www.digitizationguidelines.gov/guidelines/FADGI%20Technical%20Guidelines%20for%20Digitizing%20Cultural%20Heritage%20Materials_3rd%20Edition_05092023.pdf

Relevant principles:

- objective image-quality measurement
- documented quality-assurance methods
- documentation of imaging and processing
- preservation of the original record’s appearance
- avoidance of transformative image alteration
- 300 ppi-class capture for high-quality textual-document imaging, with higher resolution when detail requires it

Protocol implementation:

- 300 ppi default render
- 400 ppi escalation
- 600 ppi problem-crop escalation
- original full-page render retained
- review derivatives documented
- no source-content alteration
- image process recorded in metadata

## 2. U.S. National Archives — 36 CFR 1236 guidance

Sources:

- *Digitizing Records: Quality Management*
- https://records-express.blogs.archives.gov/2023/05/30/digitizing-records-quality-management/
- *Digitizing Records: The Importance of Validation*
- https://records-express.blogs.archives.gov/2023/06/01/digitizing-records-the-importance-of-validation/
- *Digitizing Records: Requirements for Paper and Photographs*
- https://records-express.blogs.archives.gov/2023/06/07/digitizing-records-requirements-for-paper-and-photographs/
- *Digitizing Records: Documentation*
- https://records-express.blogs.archives.gov/2023/05/25/digitizing-records-documentation/

Relevant principles:

- quality assurance, quality control, inspection, corrective action, and validation are distinct
- 100% of image files should open and display
- visual inspection is required
- failed samples require corrective action
- validation occurs after digitization and should be independent from routine QC
- project documentation and metadata are required
- modern textual paper records use at least 300 ppi in NARA’s permanent-record guidance

Protocol implementation:

- separate G1 rendering, G2 transcription, G7 export, and G8 validation gates
- 100% file-openability requirement
- independent final validation pass
- project manifest, page register, batch plan, provenance, and audit report
- corrective-action loop before approval

## 3. UK Government AQuA Book, 2025

Source:

- *The AQuA Book*
- https://www.gov.uk/guidance/the-aqua-book

Relevant principles:

- assurance proportional to risk and complexity
- all analysis should be assured
- analyst and assurer should be independent to an appropriate degree
- quality assurance throughout the lifecycle
- explicit roles: commissioner, analyst, assurer, approver
- documentation, testing, peer review, automation, version control, delivery, and sign-off
- robust version control for changes

Protocol implementation:

- preflight risk scoring
- Tier 1-4 assurance
- analyst/assurer/approver roles
- final independent validation
- monotonic versions
- documented sign-off and assurance state
- final publication gate

## 4. UK Government Data Quality Framework

Source:

- *The Government Data Quality Framework*
- https://www.gov.uk/government/publications/the-government-data-quality-framework/the-government-data-quality-framework

Relevant dimensions:

- accuracy
- completeness
- uniqueness
- consistency
- timeliness
- validity

Protocol implementation:

- accuracy: direct source checks
- completeness: 100% page register and record coverage
- uniqueness: record IDs and source-order checks
- consistency: page, batch, section, and cross-sheet reconciliation
- timeliness: current version and release metadata
- validity: numeric types, row types, formulas, and range checks

## 5. ICAEW — Twenty Principles for Good Spreadsheet Practice

Source:

- *20 Principles for Good Spreadsheet Practice, 2024 Edition*
- https://www.icaew.com/technical/technology/excel-community/20-principles-for-good-spreadsheet-practice-2024-edition

Relevant principles:

- consistent spreadsheet methodology
- risk-based design and management
- built-in checks, controls, and alerts from the outset
- testing and independent review
- backups and version control

Protocol implementation:

- standard sheet architecture and colors
- checks designed before transcription
- row/page/batch/workbook control hierarchy
- export and reload verification
- no-overwrite versioning
- separate final QA workbook

## 6. W3C PROV

Source:

- *PROV-O: The PROV Ontology*
- https://www.w3.org/TR/prov-o/

Relevant concepts:

- Entity
- Activity
- Agent
- derivation and attribution

Protocol implementation:

- source PDF, page image, workbook, and report as entities
- rendering, transcription, review, and export as activities
- analyst, assurer, approver, and software as agents
- explicit `Derived_From`, hashes, timestamps, and version fields

## 7. BagIt

Source:

- RFC 8493, *The BagIt File Packaging Format (V1.0)*
- https://www.rfc-editor.org/rfc/rfc8493.html

Relevant principles:

- payload directory
- tag files
- manifests
- reliable storage and transfer
- packaging without needing to interpret payload semantics

Protocol implementation:

- BagIt-compatible final package
- `data/` payload
- `bag-info.txt`
- `manifest-sha256.txt`
- `tagmanifest-sha256.txt`

## 8. NIST Secure Hash Standard

Source:

- FIPS 180-4, *Secure Hash Standard*
- https://csrc.nist.gov/pubs/fips/180-4/upd1/final

Relevant principle:

- cryptographic message digests can detect file changes

Protocol implementation:

- SHA-256 for sources, authoritative workbooks, audit reports, render panels, and package manifests

## Research-to-protocol conclusion

The strongest shared message across the sources is that quality must be designed into the lifecycle, documented, proportionate to risk, independently validated where possible, and preserved through versioned, verifiable packages.

That is the organizing principle of Protocol v2.0.

---

<!-- Source module: 14_OPERATOR_CHECKLIST.md -->

# Operator Checklist

## Before work

- [ ] Source opens
- [ ] SHA-256 captured
- [ ] Original copied read-only
- [ ] Prior approved workbook protected
- [ ] Page count confirmed
- [ ] Page Register created
- [ ] Source type classified
- [ ] Risk score assigned
- [ ] QA tier assigned
- [ ] Batch plan created
- [ ] Blocking questions consolidated

## For every batch

- [ ] Pages rendered at 300 ppi
- [ ] Rotation corrected in derivative
- [ ] Ambiguous fields escalated to 400 or 600 ppi
- [ ] Full-page images retained
- [ ] First and last boundary confirmed
- [ ] Source order continuous
- [ ] Record IDs unique
- [ ] Blanks preserved
- [ ] Parentheses stored as negative
- [ ] Row types assigned
- [ ] Source and calculated fields separated
- [ ] Row checks pass
- [ ] Page checks pass
- [ ] Batch checks pass
- [ ] Expected source variances have exception IDs
- [ ] No unexplained FAIL
- [ ] No formula errors
- [ ] Key sheets rendered
- [ ] Standalone workbook exported
- [ ] Cumulative master exported
- [ ] Exports reloaded
- [ ] SHA-256 created
- [ ] Batch audit report written
- [ ] Batch approved and integrated

## Final integration

- [ ] 100% pages approved
- [ ] 100% batches approved
- [ ] Statement equations pass
- [ ] Schedule equations pass
- [ ] Linkage Matrix passes
- [ ] accepted issues counted
- [ ] unresolved issues equal zero
- [ ] exact FAIL scan equals zero
- [ ] formula-error scan equals zero
- [ ] final files reloaded
- [ ] visual panels reviewed
- [ ] Publication Manifest complete
- [ ] authoritative master identified
- [ ] source PDF included
- [ ] BagIt-compatible package created
- [ ] SHA-256 manifests created
- [ ] final limitations disclosed

---

<!-- Source module: 15_CHANGELOG.md -->

# Protocol Changelog

## Version 2.0 — 2026-06-21

Research-integrated rewrite based on the A/8407/Add.1 conversion.

Added:

- blocker-only question policy
- automatic source preflight
- risk scoring and QA tiers
- semantic batching rules
- 300/400/600 ppi rendering ladder
- explicit source-authority hierarchy
- row-type arithmetic
- source/calculated/variance separation
- nine acceptance gates
- independent validation phase
- exception taxonomy
- W3C PROV-inspired provenance
- monotonic versioning and recovery procedure
- BagIt-compatible packaging
- SHA-256 manifests
- final linkage matrix
- publication manifest
- machine-readable defaults and decision matrix
- CSV register templates
- A/8407/Add.1 case study

Removed or changed:

- style template is no longer required
- perfect example is optional
- routine user confirmation is prohibited
- single `.xlsx` delivery is replaced by controlled package delivery for significant projects
- spot checking is no longer sufficient for high-risk financial numeric cells
- generic dashboard/report requirements are replaced by source-appropriate presentation
- final validation is separate from routine batch QC

## Version 1.0

Initial protocol pack focused on style consistency, formula checks, README, Dashboard, Report, and Changelog.
