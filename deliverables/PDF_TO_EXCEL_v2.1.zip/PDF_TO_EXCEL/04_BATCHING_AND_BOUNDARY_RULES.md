# Batching and Boundary Rules

## Why batching is mandatory

Batching isolates errors, provides recovery checkpoints, and allows page-level reconciliation before the cumulative master is changed.

Batching is mandatory when any of these is true:

- more than 10 source pages
- more than 150 structured records
- more than one table schema
- more than one financial statement or schedule
- scanned or rotated pages with dense numeric content
- section totals occur before the end of the source
- source order spans multiple pages
- statement-to-schedule linkages exist
- known or suspected source inconsistencies exist

## Boundary priority

Choose boundaries in this order:

1. End of statement or schedule
2. Printed subtotal or grand total
3. New accounting section
4. Hard heading change
5. New table schema
6. End of entity group
7. Page-count or record-count limit

Do not create equal-size batches when a semantic boundary is nearby.

## Default batch sizes

| Source type | Default batch |
|---|---|
| Dense ledger or project schedule | 3–5 pages or 100–150 records |
| Moderate financial table | 5–8 pages |
| Simple short schedule | entire schedule |
| Boundary or closing-total page | 1–3 pages |
| Narrative with numbered paragraphs | 5–10 pages, preserving section sequence |
| Mixed narrative and tables | split by document part |
| Final integration | separate zero-source batch |

Use the smaller limit when risk is High or Critical.

## Mandatory boundary controls

Every batch plan must state:

- Batch_ID
- PDF page range
- printed page range
- section
- expected first entity or paragraph
- expected last entity or paragraph
- opening source order
- expected closing source order
- expected row count, if known
- opening balance or carried subtotal
- expected closing subtotal
- source anomalies
- linked statement or schedule
- next batch

## Special boundary rules

### New section begins mid-document

Prefer a new batch at the first page of the new section.

### Page contains both detail and final totals

Keep the page in the closing batch. Do not move printed totals into a separate workbook without the detail they close unless the page is explicitly treated as a source-control page.

### Repeated or incorrect heading

Do not let the heading alone determine the batch. Use:

- preceding section
- following section
- source-order continuity
- subtotal boundaries
- printed page sequence
- table schema
- narrative cross-reference

Record the heading as an anomaly.

### Row continues across pages

Keep both page fragments in the same batch whenever feasible. If not feasible, record a continuation key and prohibit duplicate counting.

### Narrative sequence

Never split in a way that loses paragraph numbering, footnote linkage, or section heading context.

## Batch state machine

A batch moves through:

1. Planned
2. Rendered
3. Extracted
4. Self-reviewed
5. Reconciled
6. Exported
7. Reload-verified
8. Approved
9. Integrated

A batch cannot skip a state.

## Batch approval conditions

- all planned pages present
- page images open
- first and last boundary markers match
- source order continuous
- no duplicate record IDs
- expected page counts pass
- expected batch totals pass
- all failures resolved or accepted
- audit report written
- standalone and cumulative files exported
- exports reloaded
- checksums produced
