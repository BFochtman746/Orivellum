# Autonomy and Question Policy

## Objective

Reduce user interruptions without increasing conversion risk.

The operator applies documented defaults, records the decision, and continues. A question is permitted only when the answer changes the meaning, legal status, structure, or safe recoverability of the output and cannot be resolved from the source or supplied files.

## Decision hierarchy

Use this order:

1. Explicit user instruction
2. Existing approved workbook or style specification
3. Source-document evidence
4. This protocol’s defaults
5. Conservative reversible decision with a Decision Log entry
6. One blocking question

## Blocking conditions

Ask the user only when at least one condition below is true.

### BQ-01 — Competing authoritative sources

Two or more source files contain conflicting content and there is no reliable indication which one governs.

Default question:

> I found conflicting source versions. I can proceed with [file A] as the default because [evidence], while preserving [file B] as a reference. Confirm A, choose B, or tell me the precedence rule.

### BQ-02 — Required compatibility target is unknown

The user explicitly requests an update to an existing workbook or downstream system, but the prior workbook, schema, required column order, or import specification is missing.

Do not ask when building a new workbook from scratch.

### BQ-03 — Source is unreadable after escalation

A critical field remains unreadable after:

- full-page render at 300 ppi
- upright orientation
- crop at 400 ppi
- crop at 600 ppi
- comparison with the PDF text layer
- comparison with neighboring rows and totals

Ask one question containing all unresolved fields and the best candidate reading.

### BQ-04 — Transformation is requested but undefined

The user asks for currency conversion, translation, reclassification, restatement, or normalization without specifying the governing date, rate, language, or accounting rule.

No question is needed for faithful source transcription.

### BQ-05 — Security or access prevents work

The source is password-protected, corrupt, incomplete, or inaccessible.

### BQ-06 — Material interpretation has no reversible default

A choice would change financial meaning or legal interpretation and cannot be represented as separate source and calculated values.

### BQ-07 — Final approval requires an unavailable human role

The user requires regulatory, legal, certified, or independently signed validation. The operator may prepare the evidence but must ask who will perform or authorize the required sign-off.

## Non-blocking matters that must not cause a question

| Situation | Automatic action |
|---|---|
| No style template | Apply protocol standard workbook architecture and colors |
| No prior workbook | Create a new controlled workbook |
| Scanned PDF | Render and visually transcribe |
| Hybrid PDF | Use text layer as locator, image as authority |
| Rotated page | Rotate rendered derivative upright |
| Blank numeric cell | Preserve blank |
| Explicit zero | Store numeric zero |
| Parenthesized number | Store negative numeric value |
| Dash or em dash | Preserve as source marker; do not assume zero |
| Repeated table header | Deduplicate in structured data but preserve page evidence |
| Continued row or entity | Continue only when visually supported |
| Printed total disagrees with detail | Preserve both and create an exception |
| Heading conflicts with section continuity | Classify by strongest structural evidence and preserve the heading anomaly |
| Page contains final subtotal | Keep with closing batch or isolate as a control page |
| PDF is large | Batch automatically |
| User does not name output files | Use protocol naming convention |
| User does not specify render resolution | Use 300 ppi default |
| User does not request macros | Use no macros or VBA |
| User does not specify formula style | Use transparent native Excel formulas |
| User does not specify delivery package | Create standard controlled package |

## Consolidated-question rule

When blocking questions exist:

1. Complete all non-blocked work first.
2. Ask one message, not multiple sequential questions.
3. Group unresolved items by page and field.
4. State the proposed default.
5. Explain the consequence of each option.
6. Continue immediately after the answer.

## Decision Log

Every non-obvious automatic decision must record:

- Decision_ID
- date and time
- batch
- page
- issue
- options considered
- selected decision
- evidence
- reversibility
- whether user input was required
- reviewer
