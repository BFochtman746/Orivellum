# Edge Case Catalog

## EC-001 — Blank numeric cell

**Default:** preserve blank.

**Do not:** convert to zero.

## EC-002 — Explicit zero

**Default:** numeric zero with source-input formatting.

## EC-003 — Parenthesized amount

**Default:** negative numeric value.

**Check:** row-type arithmetic may use a different balance direction.

## EC-004 — Dash or em dash

**Default:** preserve as a source marker or blank code.

**Do not:** assume zero.

## EC-005 — Repeated page header

**Default:** omit from structured detail, preserve in page evidence.

## EC-006 — Repeated incorrect heading

**Default:** classify using section continuity, source order, subtotal boundaries, and neighboring pages. Preserve heading anomaly.

## EC-007 — Row split across pages

**Default:** one logical record with both source pages or an explicit continuation record.

## EC-008 — Country or entity continued from prior page

**Default:** continue only when visual layout and sequence support it.

## EC-009 — Source total disagrees with detail

**Default:** preserve both; calculate variance; investigate; create exception if verified.

## EC-010 — Source row arithmetic disagrees

**Default:** source fields remain unchanged; calculated fields show independent arithmetic; record expected variance.

## EC-011 — Rounded category rows do not equal rounded total

**Default:** preserve displayed rows and total separately.

## EC-012 — Percentage does not equal displayed numerator and denominator

**Default:** preserve printed percentage and calculate independent ratio.

## EC-013 — Narrative amount conflicts with financial statement

**Default:** preserve both and cross-reference with an exception.

## EC-014 — Scanned page with no useful text layer

**Default:** visual transcription from rendered page.

## EC-015 — OCR digit conflict

**Default:** page image wins.

## EC-016 — Small print

**Default:** 400 ppi crop; escalate to 600 ppi if unresolved.

## EC-017 — Rotated page

**Default:** retain original render and create upright derivative.

## EC-018 — Skewed scan

**Default:** create a deskewed review derivative without modifying the original render.

## EC-019 — Table schema changes mid-document

**Default:** new batch or new table model at the change.

## EC-020 — Page contains detail and grand total

**Default:** keep in closing batch.

## EC-021 — Multiple subtotal levels

**Default:** explicit Record_Type and separate formulas for each level.

## EC-022 — Deduction row

**Default:** row-specific formula based on accounting meaning; do not copy ordinary expense formula blindly.

## EC-023 — Reserve row

**Default:** preserve source sign and define formula convention explicitly.

## EC-024 — Footnote affects a number

**Default:** link footnote code to the affected record and preserve full text.

## EC-025 — Footnote marker appears as a digit

**Default:** use page layout and superscript position; do not treat as amount.

## EC-026 — Unreadable critical digit

**Default:** exhaust render escalation and arithmetic evidence, then ask one blocking question.

## EC-027 — Missing style template

**Default:** protocol standard style.

## EC-028 — Missing prior workbook

**Default:** create new workbook unless the user explicitly requested a compatible update.

## EC-029 — Formula passes but source is incomplete

**Default:** fail completeness. Arithmetic agreement cannot prove page completeness.

## EC-030 — Grand total passes but page total fails

**Default:** batch remains unapproved.

## EC-031 — Exported workbook differs from in-memory workbook

**Default:** exported file is not approved; repair and re-export.

## EC-032 — Tool crash

**Default:** reload latest approved export and resume unapproved work only.

## EC-033 — Duplicate record ID

**Default:** fail uniqueness; investigate before approval.

## EC-034 — Source-order gap

**Default:** fail completeness unless a documented non-record page explains the gap.

## EC-035 — Narrative punctuation uncertainty

**Default:** preserve best visual reading and note uncertainty; for publication-critical text, require second pass.

## EC-036 — Handwritten annotation

**Default:** preserve as an annotation record; do not merge into printed text unless clearly intended.

## EC-037 — Hidden or filtered workbook rows

**Default:** avoid hidden source data; all control-relevant records must be visible or documented.

## EC-038 — External workbook link

**Default:** replace with internal controlled values or formulas unless explicitly required.

## EC-039 — Formula error masked by IFERROR

**Default:** do not use IFERROR to conceal an unexpected error.

## EC-040 — Multiple source versions

**Default:** apply BQ-01 and ask one precedence question.
