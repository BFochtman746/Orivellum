# Research Update and Optimization Addendum — August 2026

## Purpose

This addendum brings the v2.0 research basis (see `13_RESEARCH_BASIS_AND_STANDARDS.md`) up to date with the 2025–2026 state of the art in document-to-spreadsheet conversion, and specifies concrete protocol optimizations. It does not replace any v2.0 rule; it strengthens the extraction and verification stages.

## 1. What the current research says

### 1.1 Multimodal LLMs now beat OCR on cell content; vision models still win on structure

Benchmarking on PubTables-1M using the GriTS metric (Nunes et al., *Benchmarking Table Extraction: Multimodal LLMs vs Traditional OCR*, XLLM Workshop, ACL 2025) found:

- Deep-learning computer-vision models (e.g. Table Transformer, TATR) retain a slight edge at recovering **table structural layout** (row/column grid, spans).
- Multimodal LLMs (GPT-4o class, Phi-3 Vision, Granite Vision) are **far better at reading cell text content** from rendered images.

Implication for this protocol: the v2.0 rule "rendered page image is authoritative, OCR is a locator only" remains correct, but the transcription channel should be a multimodal model reading the rendered image, optionally guided by a structure model's grid proposal — not classical OCR.

### 1.2 Open-source structured extraction has matured

- **Docling** (IBM, MIT license, 60k+ GitHub stars) converts PDFs with dedicated table-structure models and, as of 2026, VLM-based table extraction (Granite Vision table-structure support). Suitable as an automated *second opinion* channel.
- For **born-digital PDFs**, text-layer extractors (pdfplumber, Camelot for ruled tables, tabula) read the embedded text exactly — zero transcription error on the characters themselves — and fail only on structure. Current practice ranks text-layer extraction first for born-digital sources and reserves image transcription for scans.

### 1.3 Verification research has converged on three patterns

- **Reconstruction-as-Validation** (RaV-IDP, 2026): re-render the extracted data and compare it against the source to catch faithfulness errors, rather than trusting extractor confidence.
- **Atomic claim verification / grounding** (FinGround, 2026; LREC-FNP 2026): every extracted financial value must be traceable to an exact source location, and verification operates per-value, not per-document. (v2.0 provenance already anticipated this; v2.1 makes the per-cell check mandatory for numeric cells in Tier 2+.)
- **Calibrated confidence and abstention** (conformal prediction for key-information extraction, IJDAR 2026; ConfBench, 2026): model self-reported confidence is unreliable; systems should route low-agreement fields to review instead of guessing. This matches the v2.0 exception register — the optimization is to feed it *automatically* from extraction disagreement.

### 1.4 Silent page loss is a recognized failure mode

Extractor-certification tooling (e.g. pdfmux-style verification, 2026) exists specifically because parsers silently drop pages. The v2.0 page register already defends against this; v2.1 makes the reconciliation an explicit acceptance gate rather than an operator habit.

## 2. Protocol optimizations (v2.1)

### O-1. Dual-channel extraction (replaces single-channel transcription)

For every batch, produce two **independent** extractions:

- Channel A — transcription from the rendered page image (multimodal model or human), per `05_SOURCE_RENDERING_AND_TRANSCRIPTION_SOP.md`.
- Channel B — machine extraction: text-layer extraction for born-digital sources; a structure-model/Docling-class pipeline for scans.

Compare channel outputs cell by cell. Agreement ⇒ accept. Disagreement ⇒ the cell enters the exception register with both candidate values and is resolved against the rendered image at escalated resolution. Never average or silently prefer one channel.

### O-2. Deterministic recalculation gate (new acceptance gate 10)

Before any milestone export is accepted:

1. Reload the exported workbook with an independent engine (not the tool that wrote it).
2. Recalculate all formulas; the workbook must contain **zero** error cells (#REF!, #DIV/0!, #VALUE!, #NAME?, #N/A) in non-quarantined ranges.
3. Recalculated values must match stored values within rounding tolerance.
4. **Every cross-sheet reference must resolve.** A renamed or deleted sheet must fail this gate. (Motivating defect: a check formula referencing a renamed review sheet passed visual inspection because its cached value looked correct — see `15_CHANGELOG.md` v2.1.)

### O-3. Confidence-tiered exception routing

Extraction disagreement (O-1), sub-threshold structure-model confidence, and unresolved OCR-locator conflicts route the affected cells to the exception register automatically. The protocol's abstention rule is explicit: **an empty cell plus an exception row is always preferred over a guessed value.**

### O-4. Page-completeness certification

At batch close and again at final validation, reconcile: page register count = rendered image count = pages represented in extraction output = pages referenced by provenance. Any shortfall is a blocking failure, not a warning.

### O-5. Tooling reference (2026)

| Purpose | Recommended | Notes |
|---|---|---|
| Born-digital text-layer extraction | pdfplumber; Camelot (ruled tables) | exact characters, structure is the risk |
| Structure recognition on scans | Table Transformer (TATR); Docling pipeline | best grid recovery |
| Cell-content transcription | multimodal LLM on 300–600 ppi renders | per XLLM/ACL 2025 findings |
| Independent recalculation | `formulas` (Python) or LibreOffice headless | gate O-2 |
| Package integrity | SHA-256 manifests, BagIt layout | unchanged from v2.0 |

## 3. Sources

- Nunes et al., *Benchmarking Table Extraction: Multimodal LLMs vs Traditional OCR*, XLLM Workshop, ACL 2025. https://aclanthology.org/2025.xllm-1.2/
- Docling project (IBM). https://github.com/docling-project/docling — VLM table-structure extraction added 2026.
- *RaV-IDP: A Reconstruction-as-Validation Framework for Faithful Intelligent Document Processing*, arXiv, 2026.
- *FinGround: Detecting and Grounding Financial Hallucinations via Atomic Claim Verification*, arXiv, 2026.
- *Beyond Accuracy: Understanding Model Confidence in Key Information Extraction with Conformal Prediction*, IJDAR, 2026.
- *ConfBench: Can You Trust the Confidence? Vision-Language Models on Document Extraction*, arXiv, 2026.
- *Verifiable Financial Enterprise Question Answering via Inference-Time Grounding and Traceability*, FNP Workshop @ LREC 2026.
