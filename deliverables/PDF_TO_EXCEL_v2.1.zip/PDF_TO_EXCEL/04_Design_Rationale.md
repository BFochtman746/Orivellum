# Design Rationale — Why Every Convention Exists

## 1. YELLOW CELLS (`FFF2CC`) — Input / Editable Assumptions

**Why:** These are the only cells a user should ever edit. Everything downstream — every subtotal, every grand total, every dashboard KPI, every report narrative — is formula-dependent on these cells.

**What happens if broken:** If the AI hardcodes a total instead of using a yellow input, the user cannot update the workbook. The entire file becomes static and loses its value as a living model.

**Edge case:** A zero value is still an input. It must be yellow, not blank. Blank means "not reported." Zero means "reported as zero."

---

## 2. GREEN CELLS (`E2EFDA`) — Formula Output / Calculated Value

**Why:** These cells signal "do not touch." They are the engine of the workbook. If a user overwrites a green cell with a hardcoded value, the data flow breaks silently — the cell looks correct but no longer updates when inputs change.

**What happens if broken:** The workbook becomes a static report masquerading as a model. The user edits inputs, but totals don't change. Trust is destroyed.

**Edge case:** Every subtotal, grand total, average, percentage, and cross-sheet reference must be green. No exceptions.

---

## 3. BLUE CELLS (`DDEBF7`) — Reference Data / Metadata / Footnotes

**Why:** These cells provide context but should never participate in calculations. A footnote, an N/A marker, or a metadata label is not a number. If SUM() tries to include it, Excel either errors or silently skips it — both are dangerous.

**What happens if broken:** N/A becomes 0 in a SUM formula. The total is wrong but looks correct. Or a footnote text causes a #VALUE! error that cascades.

**Edge case:** "N/A" and "—" are different. N/A = not tracked (blue). "—" = not reported (blue). 0 = measured zero (yellow). The AI must preserve these distinctions exactly as the PDF presents them.

---

## 4. DASHBOARD KPI CARDS — ▲/▼ Arrows with Prior Period

**Why:** The arrow provides instant visual direction. The prior period value below provides context without requiring the user to navigate to another sheet. This is the standard executive summary format.

**What happens if broken:** Hardcoded arrows that don't match the actual direction of change. A ▲ on a declining metric. The dashboard becomes misleading.

**Edge case:** The arrow should be formula-driven, not typed. `=IF(current > prior, "▲", "▼")` ensures it always matches reality.

---

## 5. REPORT NARRATIVE SECTIONS — Standard QBR Structure

**Why:** Executive Summary → Financial Performance → Regional Performance → Production & Operations → Outlook & Risks. This is the universally understood quarterly business review structure. Deviating from it forces the reader to re-learn the document.

**What happens if broken:** Sections are missing, reordered, or renamed. The reader cannot find the risk disclosure or the financial summary. The document fails its purpose.

**Edge case:** The AI should not invent new sections. If the PDF lacks a section (e.g., no "Production & Operations"), the Report sheet should still include the section header with a note: "Not addressed in source document."

---

## 6. README SHEET — The Navigation Compass

**Why:** A workbook without a README is a black box. The next person who opens it has no idea who built it, when, what the sheets contain, or what the colors mean. Within 6 months, the workbook is abandoned and rebuilt from scratch.

**What happens if broken:** No README → user guesses at conventions → breaks formulas → workbook becomes static → rebuild required.

**Edge case:** The README should be the FIRST sheet (leftmost tab). It is the landing page.

---

## 7. CHANGELOG SHEET — The Audit Trail

**Why:** Financial and operational workbooks are reviewed by auditors, executives, and regulators. Every material change must be traceable. "Who changed what, when, and why?"

**What happens if broken:** No changelog → no audit trail → compliance failure → workbook rejected by finance/legal.

**Edge case:** The changelog is 100% manual. No formulas. The user types each entry. The AI should create the structure and one initial entry, then leave it for manual maintenance.

---

## 8. CROSS-SHEET FORMULAS — The Living Model

**Why:** If the Report sheet hardcodes "Revenue: $27,181K" instead of linking to `=Revenue!F8`, then updating Q1 revenue requires editing two sheets. Humans forget. The Report becomes stale.

**What happens if broken:** Report and Dashboard show different numbers for the same metric. The workbook becomes internally inconsistent.

**Edge case:** Cross-sheet links should use explicit sheet names. `=Revenue!F8` is safer than `=F8` because it survives sheet reordering.

---

## 9. PRINT SETUP — The Forgotten Gate

**Why:** 80% of executive workbooks are printed or exported to PDF for board meetings. If the print preview shows cut-off columns or 47 pages of overflow, the workbook is useless.

**What happens if broken:** Print preview shows 3 pages for a 1-page table. Columns 6–8 are missing. The user manually resizes everything, breaking the layout.

**Edge case:** Wide tables (6+ columns) should be landscape. Narrative sheets should be portrait. Fit-to-width = 1 page. Never let Excel auto-scale to 50% font size.

---

## 10. NEGATIVE VALUE STYLING — The Danger Signal

**Why:** A negative number in a revenue column is unusual. It demands attention. Red fill + dark red font is the universal accounting convention for losses, refunds, and write-downs.

**What happens if broken:** Negative value displayed in normal black text. Reader misses the refund. Financial analysis is wrong.

**Edge case:** The AI should not "fix" negative values by making them positive. A $(85)K refund is real data. Preserve it exactly.

---

## 11. FOOTNOTES — The Legal Protection

**Why:** Footnotes contain restatements, corrections, disclaimers, and material disclosures. "Q3 Software revenue reflects the originally reported figure... corrected figure is $1,420K." This is legally binding text.

**What happens if broken:** Footnote dropped → user uses uncorrected Q3 figure → financial model is wrong → restatement required → liability.

**Edge case:** Footnotes should be in blue cells, merged across the relevant columns, with wrapped text. They should not participate in formulas.

---

## 12. EDGE CASES — Where 90% of Errors Hide

The AI is trained on clean data. Real-world PDFs are messy. The edge case reference document exists because the AI cannot reliably infer the correct handling from first principles.

| Edge Case | Wrong Handling | Right Handling |
|-----------|---------------|----------------|
| N/A in numeric column | Convert to 0 | Blue fill, italic, excluded from SUM |
| Blank in numeric column | Convert to 0 | Leave blank (means "not reported") |
| Zero in numeric column | Leave blank | Yellow fill, value = 0 |
| Negative revenue | Make positive | Red fill, preserve negative |
| Multi-page table | Duplicate headers | Deduplicate, single header |
| Scanned image page | Fabricate data | Placeholder sheet with note |
| Merged cells in header | Split into separate cells | Preserve merge, reconstruct in Excel |
| Superscript footnote marker | Ignore | Preserve as text, link to footnote |
| Currency symbols ($, €, £) | Strip them | Preserve in number format |
| Percentages with % sign | Convert to decimal | Preserve as 0.0% format |

---

## Summary: The Philosophy

This workbook is not a report. It is a **model**.

A report is static. A model is alive. It updates when inputs change. It cross-validates itself. It tells you when something is wrong. It is navigable, auditable, and printable.

Every convention exists to preserve that aliveness. Break the convention, and the model dies.
