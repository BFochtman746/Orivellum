# Data Flow Diagram Template

## Instructions

Copy this template and fill in the sheet names and cell references for your specific workbook. The AI will use this to build correct cross-sheet formulas.

---

## Example: Meridian FY2025 Q4 Report

```
PDF Source: Meridian FY2025 Q4 Report.pdf
    │
    ├─→ PAGE 2: Regional Headcount
    │       │
    │       ├─→ Sheet: Headcount
    │       │   ├── Row 5-7: Country data (yellow inputs)
    │       │   ├── Row 8: NA Subtotal =SUM(C5:C7) (green)
    │       │   ├── Row 9-11: Country data (yellow)
    │       │   ├── Row 12: EMEA Subtotal =SUM(C9:C11) (green)
    │       │   ├── Row 13-15: Country data (yellow)
    │       │   ├── Row 16: APAC Subtotal =SUM(C13:C15) (green)
    │       │   └── Row 17: Grand Total =SUM(C8,C12,C16) (green)
    │       │
    │       └─→ Dashboard KPI cards
    │           ├── A5: "▲  1,060" ← =Headcount!F17
    │           └── A6: "Q3: 1,021" ← =Headcount!F16
    │
    ├─→ PAGE 3-4: Monthly Production
    │       │
    │       ├─→ Sheet: Production
    │       │   ├── Row 5-22: Plant data (yellow inputs)
    │       │   ├── Col H: Month Total =SUM(B:G) (green)
    │       │   └── Row 23: FY Grand Total =SUM(B5:B22) (green)
    │       │
    │       ├─→ Dashboard trend table
    │       │   └── Row 15-19: Production data
    │       │
    │       └─→ Report narrative
    │           └── "Total FY2025 production reached 389,962 units..."
    │
    ├─→ PAGE 5: Quarterly Revenue
    │       │
    │       ├─→ Sheet: Revenue
    │       │   ├── Row 4-7: Segment data (yellow inputs)
    │       │   ├── Col F: FY Total =SUM(B:E) (green)
    │       │   └── Row 8: Column Total =SUM(B4:B7) (green)
    │       │
    │       ├─→ Report Financial Performance
    │       │   └── Row 13-16: Embedded table with formulas
    │       │       ├── C13: =Revenue!F8 (Total Revenue)
    │       │       ├── C14: =Margin!B5 (Q4 Margin)
    │       │       └── etc.
    │       │
    │       └─→ Dashboard trend table
    │           └── Row 15-19: Revenue data
    │
    ├─→ PAGE 7: Cost Center Allocation
    │       │
    │       └─→ Sheet: CostCenter
    │           ├── Row 5-9: Department data (yellow inputs)
    │           ├── Col G: Dept Total =SUM(B:F) (green)
    │           └── Row 10: Grand Total =SUM(B5:B9) (green)
    │
    ├─→ PAGE 6: Operating Margin Chart
    │       │
    │       └─→ Sheet: Margin
    │           ├── Row 5-8: Quarter + Margin % (yellow inputs)
    │           └── Embedded line chart
    │
    └─→ ALL SHEETS → Changelog (manual only)
```

---

## Your Workbook

```
PDF Source: [YOUR_PDF_NAME.pdf]
    │
    ├─→ PAGE [X]: [Section Name]
    │       │
    │       ├─→ Sheet: [Sheet Name]
    │       │   ├── Row [X-Y]: [Description] (yellow/green)
    │       │   └── Row [Z]: [Formula] (green)
    │       │
    │       └─→ [Downstream sheet]
    │           └── [Cell reference] ← =[Sheet]![Cell]
    │
    ├─→ PAGE [X]: [Section Name]
    │       │
    │       └─→ Sheet: [Sheet Name]
    │           └── etc.
    │
    └─→ ALL SHEETS → Changelog (manual only)
```

---

## Cross-Sheet Reference Map

| Source Sheet | Source Cell | Target Sheet | Target Cell | Formula |
|-------------|-------------|--------------|-------------|---------|
| Headcount | F17 | Dashboard | A5 | `=Headcount!F17` |
| Headcount | F16 | Dashboard | A6 | `=Headcount!F16` |
| Revenue | F8 | Report | C13 | `=Revenue!F8` |
| Revenue | F4 | Dashboard | F15 | `=Revenue!F4` |
| Production | H23 | Report | C16 | `=Production!H23` |
| Margin | B5 | Report | C14 | `=Margin!B5` |
| [Add your own] | | | | |

---

## Dependency Rules

1. **Yellow cells never reference other cells.** They are the root inputs.
2. **Green cells always reference yellow or other green cells.** Never hardcode.
3. **Blue cells never participate in formulas.** They are context only.
4. **Dashboard only references data sheets.** It never contains raw inputs.
5. **Report only references data sheets.** Narrative is static, but embedded tables are formula-driven.
6. **Changelog is 100% manual.** No formulas, no references.
