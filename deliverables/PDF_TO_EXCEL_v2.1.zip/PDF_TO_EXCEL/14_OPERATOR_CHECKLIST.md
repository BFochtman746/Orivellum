# Operator Checklist

## Before work

- [ ] Source opens
- [ ] SHA-256 captured
- [ ] Original copied read-only
- [ ] Prior approved workbook protected
- [ ] Page count confirmed
- [ ] Page Register created
- [ ] Source type classified
- [ ] Risk score assigned
- [ ] QA tier assigned
- [ ] Batch plan created
- [ ] Blocking questions consolidated

## For every batch

- [ ] Pages rendered at 300 ppi
- [ ] Rotation corrected in derivative
- [ ] Ambiguous fields escalated to 400 or 600 ppi
- [ ] Full-page images retained
- [ ] First and last boundary confirmed
- [ ] Source order continuous
- [ ] Record IDs unique
- [ ] Blanks preserved
- [ ] Parentheses stored as negative
- [ ] Row types assigned
- [ ] Source and calculated fields separated
- [ ] Row checks pass
- [ ] Page checks pass
- [ ] Batch checks pass
- [ ] Expected source variances have exception IDs
- [ ] No unexplained FAIL
- [ ] No formula errors
- [ ] Key sheets rendered
- [ ] Standalone workbook exported
- [ ] Cumulative master exported
- [ ] Exports reloaded
- [ ] SHA-256 created
- [ ] Batch audit report written
- [ ] Batch approved and integrated

## Final integration

- [ ] 100% pages approved
- [ ] 100% batches approved
- [ ] Statement equations pass
- [ ] Schedule equations pass
- [ ] Linkage Matrix passes
- [ ] accepted issues counted
- [ ] unresolved issues equal zero
- [ ] exact FAIL scan equals zero
- [ ] formula-error scan equals zero
- [ ] final files reloaded
- [ ] visual panels reviewed
- [ ] Publication Manifest complete
- [ ] authoritative master identified
- [ ] source PDF included
- [ ] BagIt-compatible package created
- [ ] SHA-256 manifests created
- [ ] final limitations disclosed
