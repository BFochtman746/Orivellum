# Intake, Preflight, and Risk Scoring

## Required inputs

Minimum:

- source PDF

Recommended:

- prior approved workbook, if updating
- domain glossary
- known page or total expectations
- desired output filename

Optional:

- style template
- perfect example
- downstream import schema

The absence of optional material must not stop the conversion.

## Preflight output

Before transcription, create a Project Manifest and Page Register containing:

- project ID
- source filename
- source SHA-256
- file size
- page count
- encryption status
- text-layer status
- source type: born-digital, scanned, hybrid
- page dimensions
- orientation
- printed-page mapping
- section classification
- table schema
- narrative presence
- footnote presence
- total/subtotal presence
- risk score
- planned batch
- render status
- review status

## Source assessment

### File integrity

Check:

- file exists
- file size is non-zero
- PDF opens
- page count is readable
- no unexpected truncation
- password/encryption status
- SHA-256 captured

### Page assessment

For every page, identify:

- portrait, landscape, rotated, or mixed
- printed page number
- table, narrative, image, signature, or mixed
- new section, continuation, subtotal, grand total, or appendix
- text-layer usefulness
- small-print risk
- low-contrast risk
- skew or distortion
- multi-column reading order
- continued entity or row
- repeated header
- footnotes
- source anomalies

## Risk scoring

Score each dimension from 0 to 3.

| Dimension | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| Image quality | clear born-digital | minor scan issues | low contrast or rotation | degraded or tiny print |
| Table density | no table | simple table | dense table | highly dense ledger |
| Schema stability | one stable schema | minor changes | multiple schemas | frequent schema changes |
| Financial criticality | descriptive | noncritical amounts | material totals | statements or audited totals |
| Boundary complexity | none | repeated headers | section changes | ambiguous section continuity |
| Cross-sheet dependency | none | one link | several links | statement/schedule network |
| Source inconsistency | none | rounding | row variance | subtotal or heading conflict |
| Narrative complexity | none | simple paragraphs | footnotes/tables | legal/audit narrative |

### Risk class

- 0–5: Low
- 6–11: Moderate
- 12–17: High
- 18–24: Critical

Static historical financial reports default to at least **High** even when the visual score is lower.

## QA tier

| Risk class | QA tier | Required assurance |
|---|---|---|
| Low | Tier 1 | complete page register, all totals, 10 source spot checks |
| Moderate | Tier 2 | 100% key numeric cells, row formulas, page totals, export reload |
| High | Tier 3 | 100% numeric cells, page/batch/section controls, cross-sheet checks, independent validation pass |
| Critical | Tier 4 | Tier 3 plus smaller batches, dual-pass transcription, extensive crops, formal sign-off evidence |

Financial statements, schedules, audited totals, and legal tables must use Tier 3 or Tier 4.

## Preflight acceptance gate

Do not begin bulk transcription until:

- source integrity passes
- all pages are registered
- source type is classified
- render plan is established
- batch plan is established
- risk and QA tier are recorded
- known cross-sheet relationships are mapped
- unresolved blockers are consolidated
