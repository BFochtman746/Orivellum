# Reference Document Pack Specification

## Purpose
This document defines the exact set of files you should upload to the AI before requesting any PDF-to-Excel conversion. The quality of the output is directly proportional to the quality of the reference pack.

## Required Files (The "Golden Set")

### 1. Style Template (`_Style_Template.xlsx`)
**What it contains:**
- README sheet with Document Control, Sheet Guide, Operating Instructions, Color Legend
- One sample data sheet showing yellow/green/blue cell conventions
- One sample Dashboard with KPI cards
- One sample Report with narrative sections
- Changelog sheet

**Why it matters:** This is the single most important file. Without it, the AI will invent its own style system.

**What to include:**
```
Sheet: README
  - Title block with emoji prefix (📊)
  - Document Control table (Owner, Version, Created, Status)
  - Sheet Guide (name + description for each sheet)
  - Operating Instructions (bullet list)
  - Color Legend (🟨 Yellow = Input, 🟩 Green = Formula, 🟦 Blue = Reference)

Sheet: Sample_Data
  - Header row with D9E1F2 fill
  - 3-5 data rows with yellow fill
  - 1 subtotal row with green fill + =SUM() formula
  - Number formatting (#,##0 or $#,##0)

Sheet: Sample_Dashboard
  - KPI card layout (label, value with ▲, prior period)
  - Gray fill background for card area
  - Trend table with header + data + total row

Sheet: Sample_Report
  - Section headers with bottom border
  - Narrative paragraphs (merged cells, wrap text)
  - 💡 insight callout row
  - Embedded data table

Sheet: Changelog
  - Standard columns: Date, Version, Changed By, Description, Impact
```

### 2. Design Rationale (`_Design_Rationale.md`)
**What it contains:** One paragraph per convention explaining WHY it exists.

**Example entries:**
```
YELLOW CELLS (FFF2CC):
  These are the only cells a user should edit. Everything downstream
  is formula-dependent. If a yellow cell changes, all green cells must
  auto-update. This creates a single source of truth.

GREEN CELLS (E2EFDA):
  These are protected formula outputs. If broken, the entire sheet's
  integrity collapses. The green color signals "do not touch."

BLUE CELLS (DDEBF7):
  Reference data, metadata, footnotes, and N/A markers. These are
  context, not inputs or calculations. They should never participate
  in SUM formulas.

DASHBOARD KPI CARDS:
  The ▲/▼ arrow convention signals direction of change vs prior
  period. The prior period value is shown below the main KPI to
  provide context without cluttering the card.

REPORT NARRATIVE SECTIONS:
  Executive Summary → Financial Performance → Regional Performance
  → Production & Operations → Outlook & Risks. This is the standard
  quarterly business review structure. The AI should preserve it.
```

### 3. Edge Case Reference (`_Edge_Case_Reference.xlsx`)
**What it contains:** 5–10 real examples of messy data and the expected handling.

**Example entries:**
```
Row 1: Negative revenue (-$85K)
  → Cell fill: FFC7CE (red)
  → Font color: 9C0006 (dark red)
  → Number format: $#,##0
  → Note: This is a refund, not an error. Preserve the negative.

Row 2: "N/A" in a numeric column
  → Cell fill: DDEBF7 (blue)
  → Font: italic, gray
  → Formula behavior: SUM() skips text cells automatically
  → Do NOT convert to 0

Row 3: Blank cell where zero was recorded
  → Cell fill: FFF2CC (yellow) — it's an input
  → Value: 0
  → Number format: $#,##0
  → Do NOT leave blank — blank means "not reported"

Row 4: Multi-page spanned table
  → Detect continuation headers
  → Deduplicate repeated header rows
  → Preserve single header in Excel

Row 5: Scanned image page with no extractable text
  → Create placeholder sheet: "Vendor Backlog (Image)"
  → Note: "Page submitted as scanned image — data not machine-readable"
  → Do NOT fabricate data
```

### 4. Data Flow Diagram (`_Data_Flow_Diagram.txt`)
**What it contains:** A text-based diagram showing cross-sheet dependencies.

**Example:**
```
PDF Source
    │
    ├─→ Headcount sheet (yellow inputs, green subtotals)
    │       └─→ Dashboard KPI cards (formulas link to Headcount!F17)
    │
    ├─→ Production sheet (yellow plant data, green month totals)
    │       └─→ Dashboard trend table
    │       └─→ Report narrative
    │
    ├─→ Revenue sheet (yellow quarterly data, green FY totals)
    │       └─→ Report Financial Performance table
    │       └─→ Dashboard trend table
    │
    ├─→ CostCenter sheet (yellow allocations, green dept totals)
    │       └─→ Report (if referenced)
    │
    ├─→ Margin sheet (yellow chart values)
    │       └─→ Dashboard (if referenced)
    │
    └─→ Report sheet (narrative, embedded tables with green formulas)
            └─→ Links to Revenue, Production, Headcount

All sheets → Changelog (manual only, no formulas)
```

### 5. Quality Checklist (`_Quality_Checklist.md`)
**What it contains:** The exact gates the AI must pass before declaring work done.

**See separate file: `03_Quality_Checklist.md`**

### 6. Perfect Example (`_Perfect_Example.pdf` + `_Perfect_Example.xlsx`)
**What it contains:** One complete PDF-to-Excel conversion that you consider flawless.

**Why it matters:** The AI will pattern-match against this instead of reverse-engineering from multiple files.

**What to annotate:**
- What was ambiguous in the PDF and how you resolved it
- Why you chose specific formula structures
- What you deliberately excluded and why

## Optional but Recommended Files

### 7. Previous Version (`_Previous_Version.xlsx`)
If this is an update to an existing workbook, provide the previous version so the AI can preserve existing structure and only update changed data.

### 8. Domain Vocabulary (`_Domain_Vocabulary.txt`)
If the PDF contains specialized terminology (accounting, legal, medical, biblical), provide a glossary of terms and their expected handling.

## File Naming Convention

All reference files should use the `_` prefix so they sort to the top:
```
_Style_Template.xlsx
_Design_Rationale.md
_Edge_Case_Reference.xlsx
_Data_Flow_Diagram.txt
_Quality_Checklist.md
_Perfect_Example.pdf
_Perfect_Example.xlsx
_Previous_Version.xlsx
_Domain_Vocabulary.txt
```

## Upload Order

1. Upload the source PDF
2. Upload the reference pack (all `_` files)
3. Paste the Master Prompt
4. Only then request the conversion

## What Happens If You Skip Files

| Missing File | Impact on Output |
|-------------|------------------|
| Style Template | AI invents its own style. Inconsistent colors, fonts, and layout. |
| Design Rationale | AI applies conventions mechanically without understanding edge cases. |
| Edge Case Reference | N/A becomes 0, negatives become positive, footnotes are dropped. |
| Data Flow Diagram | Cross-sheet links are broken or hardcoded. Report doesn't update. |
| Quality Checklist | AI declares "done" without verifying formulas. Errors slip through. |
| Perfect Example | AI guesses at structure. Output may be 50% different from your expectation. |
