# Quality Checklist — PDF-to-Excel Conversion

## MANDATORY GATES

The AI must pass ALL gates before declaring the work complete. No exceptions.

---

### GATE 1: Structural Integrity

- [ ] All sheets present in correct order: README → Data sheets → Dashboard → Report → Changelog
- [ ] README contains: Document Control, Sheet Guide, Operating Instructions, Color Legend
- [ ] Changelog contains at least one entry (initial creation)
- [ ] No sheets named "Sheet1", "Sheet2", etc. — all have descriptive names
- [ ] No hidden sheets containing data

### GATE 2: Formula Verification

- [ ] Every subtotal is a `=SUM()` formula, not a hardcoded value
- [ ] Every grand total is a `=SUM()` formula referencing subtotals
- [ ] Every average is an `=AVERAGE()` formula
- [ ] Every percentage is a calculated formula, not hardcoded
- [ ] Cross-sheet references use explicit sheet names (`=Revenue!F4` not `=F4`)
- [ ] No circular references (use Excel's formula auditing tools)
- [ ] Formula ranges are correct (e.g., `=SUM(C5:C7)` not `=SUM(C6:C8)`)
- [ ] No `#REF!`, `#VALUE!`, `#DIV/0!`, or `#N/A` errors anywhere

**Verification method:** Load workbook, go to Formulas → Error Checking. Must show "No errors found."

### GATE 3: Manual Sum Verification

For EACH data sheet, pick at least 3 rows/columns and verify:

- [ ] **Headcount:** NA subtotal = US + Canada + Mexico (all 4 quarters)
- [ ] **Headcount:** Grand Total = NA + EMEA + APAC (all 4 quarters)
- [ ] **Production:** Month Total = Plant A + B + C + D + E + F (3 random months)
- [ ] **Production:** FY Grand Total = sum of all Month Totals
- [ ] **Revenue:** FY Total per segment = Q1 + Q2 + Q3 + Q4 (all 4 segments)
- [ ] **Revenue:** Column Total per quarter = sum of all segments
- [ ] **CostCenter:** Dept Total = sum of all cost categories (all 5 departments)
- [ ] **CostCenter:** Grand Total = sum of all Dept Totals

**Verification method:** Calculate manually with a calculator. Compare to formula result. Tolerance: exact match for integers, ±0.01 for decimals.

### GATE 4: Data Point Spot-Checks

Pick at least 10 random cells across all sheets and verify against the PDF:

- [ ] Cell 1: ________ (expected: ________)
- [ ] Cell 2: ________ (expected: ________)
- [ ] Cell 3: ________ (expected: ________)
- [ ] Cell 4: ________ (expected: ________)
- [ ] Cell 5: ________ (expected: ________)
- [ ] Cell 6: ________ (expected: ________)
- [ ] Cell 7: ________ (expected: ________)
- [ ] Cell 8: ________ (expected: ________)
- [ ] Cell 9: ________ (expected: ________)
- [ ] Cell 10: ________ (expected: ________)

### GATE 5: Color Coding

- [ ] All input cells have YELLOW fill (`FFF2CC`)
- [ ] All formula cells have GREEN fill (`E2EFDA`)
- [ ] All reference/footnote/N/A cells have BLUE fill (`DDEBF7`)
- [ ] All header rows have consistent fill (D9E1F2 or DARK_BLUE with white font)
- [ ] No cells have inconsistent or missing fill
- [ ] Negative values have RED fill (`FFC7CE`) + dark red font (`9C0006`)

### GATE 6: Number Formatting

- [ ] Currency values use `$#,##0` or `$#,##0.00`
- [ ] Percentages use `0.0%`
- [ ] Large integers use `#,##0`
- [ ] Dates use `YYYY-MM-DD` or `MMM-YYYY`
- [ ] No "General" format on numeric cells
- [ ] No trailing decimals on integer values

### GATE 7: Edge Case Handling

- [ ] "N/A" cells are blue, italic, and excluded from SUM formulas
- [ ] Zero values are displayed as `0` (not blank)
- [ ] Blank cells are truly blank (not zero, not N/A)
- [ ] Negative values are visually distinct (red)
- [ ] Footnotes are preserved in blue cells with merged formatting
- [ ] Multi-page tables have deduplicated headers
- [ ] Scanned/unextractable pages have placeholder sheets (not fabricated data)

### GATE 8: Cross-Sheet Integrity

- [ ] Dashboard KPIs reference data sheets with formulas (not hardcoded)
- [ ] Report embedded tables reference data sheets with formulas
- [ ] Changing a yellow input cell updates all downstream green cells
- [ ] No orphaned references (formulas pointing to deleted cells)

**Verification method:** Change one input cell in Headcount. Verify Dashboard and Report update automatically.

### GATE 9: Print Readiness

- [ ] A4 paper size set
- [ ] Landscape orientation for tables with 6+ columns
- [ ] Portrait orientation for narrative and narrow tables
- [ ] Fit-to-width enabled (1 page wide)
- [ ] Gridlines turned OFF
- [ ] Margins: 0.5" left/right, 0.75" top/bottom
- [ ] Header: "[Company] — [Report Name]"
- [ ] Footer: "Internal — Not for External Release | Page X of Y"
- [ ] Print preview shows no overflow, no cut-off columns

### GATE 10: Narrative & Report Quality

- [ ] Report sheet has all standard sections: Executive Summary, Financial Performance, Regional Performance, Production & Operations, Outlook & Risks
- [ ] Executive Summary is 2–4 sentences summarizing the period
- [ ] Financial Performance includes embedded data table with formulas
- [ ] At least one 💡 insight callout highlighting a key finding
- [ ] Outlook section includes specific risks with dollar amounts and dates
- [ ] All narrative text is wrapped and readable (no overflow)
- [ ] Section headers have bottom border or distinct formatting

### GATE 11: Chart Quality (if applicable)

- [ ] Charts have descriptive titles
- [ ] Axis labels are present and clear
- [ ] Data labels show values (not just points)
- [ ] Legend is present if multiple series
- [ ] Chart style is consistent with workbook theme
- [ ] No chart overlaps data or other charts

### GATE 12: Final Audit Report

The AI must produce a written audit report containing:

```
BACKWARDS CHECK REPORT
======================

1. FORMULA VERIFICATION
   - Headcount: X formulas checked, X passed, X failed
   - Production: X formulas checked, X passed, X failed
   - Revenue: X formulas checked, X passed, X failed
   - CostCenter: X formulas checked, X passed, X failed

2. MANUAL SUM VERIFICATION
   - [List each manual calculation with expected vs actual]

3. DATA POINT SPOT-CHECKS
   - [List 10 cells with expected vs actual]

4. STRUCTURAL INTEGRITY
   - Circular references: None found / Found: [details]
   - Cross-sheet links: All functional / Broken: [details]
   - Print preview: Clean / Issues: [details]

5. EDGE CASE HANDLING
   - Negative values: Correctly styled / Issues
   - N/A markers: Correctly styled / Issues
   - Footnotes: Preserved / Missing

6. OVERALL ASSESSMENT
   - Pass / Fail with specific remediation items
```

---

## FAILURE PROTOCOL

If ANY gate fails:
1. Do NOT deliver the file
2. Fix the specific issue
3. Re-run the full checklist
4. Only deliver after 100% pass rate

## POST-DELIVERY VERIFICATION (User Action)

After receiving the file, the user should:
1. Open in Excel (not just preview)
2. Go to Formulas → Error Checking → verify "No errors found"
3. Change one yellow input cell → verify all green cells update
4. Print preview each sheet → verify no overflow
5. Spot-check 5 random cells against the PDF

If any issue is found, paste the specific cell reference and expected value into the chat for correction.
