# Research Basis and Standards Mapping

## Purpose

Version 2.0 incorporates current authoritative guidance on digitization, analytical quality assurance, spreadsheet engineering, provenance, and digital packaging.

The protocol adapts these principles to PDF-to-Excel conversion. It does not claim formal regulatory compliance.

## 1. Federal Agencies Digital Guidelines Initiative — FADGI

Source:

- *Technical Guidelines for Digitizing Cultural Heritage Materials, Third Edition*, 2023
- https://www.digitizationguidelines.gov/guidelines/FADGI%20Technical%20Guidelines%20for%20Digitizing%20Cultural%20Heritage%20Materials_3rd%20Edition_05092023.pdf

Relevant principles:

- objective image-quality measurement
- documented quality-assurance methods
- documentation of imaging and processing
- preservation of the original record’s appearance
- avoidance of transformative image alteration
- 300 ppi-class capture for high-quality textual-document imaging, with higher resolution when detail requires it

Protocol implementation:

- 300 ppi default render
- 400 ppi escalation
- 600 ppi problem-crop escalation
- original full-page render retained
- review derivatives documented
- no source-content alteration
- image process recorded in metadata

## 2. U.S. National Archives — 36 CFR 1236 guidance

Sources:

- *Digitizing Records: Quality Management*
- https://records-express.blogs.archives.gov/2023/05/30/digitizing-records-quality-management/
- *Digitizing Records: The Importance of Validation*
- https://records-express.blogs.archives.gov/2023/06/01/digitizing-records-the-importance-of-validation/
- *Digitizing Records: Requirements for Paper and Photographs*
- https://records-express.blogs.archives.gov/2023/06/07/digitizing-records-requirements-for-paper-and-photographs/
- *Digitizing Records: Documentation*
- https://records-express.blogs.archives.gov/2023/05/25/digitizing-records-documentation/

Relevant principles:

- quality assurance, quality control, inspection, corrective action, and validation are distinct
- 100% of image files should open and display
- visual inspection is required
- failed samples require corrective action
- validation occurs after digitization and should be independent from routine QC
- project documentation and metadata are required
- modern textual paper records use at least 300 ppi in NARA’s permanent-record guidance

Protocol implementation:

- separate G1 rendering, G2 transcription, G7 export, and G8 validation gates
- 100% file-openability requirement
- independent final validation pass
- project manifest, page register, batch plan, provenance, and audit report
- corrective-action loop before approval

## 3. UK Government AQuA Book, 2025

Source:

- *The AQuA Book*
- https://www.gov.uk/guidance/the-aqua-book

Relevant principles:

- assurance proportional to risk and complexity
- all analysis should be assured
- analyst and assurer should be independent to an appropriate degree
- quality assurance throughout the lifecycle
- explicit roles: commissioner, analyst, assurer, approver
- documentation, testing, peer review, automation, version control, delivery, and sign-off
- robust version control for changes

Protocol implementation:

- preflight risk scoring
- Tier 1-4 assurance
- analyst/assurer/approver roles
- final independent validation
- monotonic versions
- documented sign-off and assurance state
- final publication gate

## 4. UK Government Data Quality Framework

Source:

- *The Government Data Quality Framework*
- https://www.gov.uk/government/publications/the-government-data-quality-framework/the-government-data-quality-framework

Relevant dimensions:

- accuracy
- completeness
- uniqueness
- consistency
- timeliness
- validity

Protocol implementation:

- accuracy: direct source checks
- completeness: 100% page register and record coverage
- uniqueness: record IDs and source-order checks
- consistency: page, batch, section, and cross-sheet reconciliation
- timeliness: current version and release metadata
- validity: numeric types, row types, formulas, and range checks

## 5. ICAEW — Twenty Principles for Good Spreadsheet Practice

Source:

- *20 Principles for Good Spreadsheet Practice, 2024 Edition*
- https://www.icaew.com/technical/technology/excel-community/20-principles-for-good-spreadsheet-practice-2024-edition

Relevant principles:

- consistent spreadsheet methodology
- risk-based design and management
- built-in checks, controls, and alerts from the outset
- testing and independent review
- backups and version control

Protocol implementation:

- standard sheet architecture and colors
- checks designed before transcription
- row/page/batch/workbook control hierarchy
- export and reload verification
- no-overwrite versioning
- separate final QA workbook

## 6. W3C PROV

Source:

- *PROV-O: The PROV Ontology*
- https://www.w3.org/TR/prov-o/

Relevant concepts:

- Entity
- Activity
- Agent
- derivation and attribution

Protocol implementation:

- source PDF, page image, workbook, and report as entities
- rendering, transcription, review, and export as activities
- analyst, assurer, approver, and software as agents
- explicit `Derived_From`, hashes, timestamps, and version fields

## 7. BagIt

Source:

- RFC 8493, *The BagIt File Packaging Format (V1.0)*
- https://www.rfc-editor.org/rfc/rfc8493.html

Relevant principles:

- payload directory
- tag files
- manifests
- reliable storage and transfer
- packaging without needing to interpret payload semantics

Protocol implementation:

- BagIt-compatible final package
- `data/` payload
- `bag-info.txt`
- `manifest-sha256.txt`
- `tagmanifest-sha256.txt`

## 8. NIST Secure Hash Standard

Source:

- FIPS 180-4, *Secure Hash Standard*
- https://csrc.nist.gov/pubs/fips/180-4/upd1/final

Relevant principle:

- cryptographic message digests can detect file changes

Protocol implementation:

- SHA-256 for sources, authoritative workbooks, audit reports, render panels, and package manifests

## Research-to-protocol conclusion

The strongest shared message across the sources is that quality must be designed into the lifecycle, documented, proportionate to risk, independently validated where possible, and preserved through versioned, verifiable packages.

That is the organizing principle of Protocol v2.0.
