# Workbook Architecture and Styling

## Standard sheets

Every significant project should contain:

1. README
2. Workflow
3. Page Register
4. Batch Control
5. Data Dictionary
6. Exceptions
7. Checks
8. Reconciliation
9. Changelog
10. Data or schedule sheets
11. Narrative sheets, where present
12. Dashboard
13. Report

Large or critical projects should also contain:

14. Decision Log
15. Question Log
16. Linkage Matrix
17. Final QA
18. Publication Manifest
19. Completion Summary

## Separation of concerns

### Source layer

Exact source values and text.

### Calculation layer

Formulas, normalized values, and independent arithmetic.

### Control layer

Checks, reconciliation, exceptions, status, and provenance.

### Presentation layer

Dashboard, report, and reader-facing summaries.

Do not mix source input and formula output in the same field.

## Color convention

| Color | Hex | Meaning |
|---|---|---|
| Yellow | `FFF2CC` | Source values or user-editable inputs |
| Green | `E2EFDA` | Formula output and calculated controls |
| Blue | `DDEBF7` | Metadata, provenance, references, review fields |
| Red | `FFC7CE` | Negative values, accepted variances, failures |
| Dark blue | `1F4E78` | Headers and section bars |
| Light gray | `F2F2F2` | Narrative background and neutral labels |

A status field is still required. Color alone is not a control.

## Standard record fields

- Record_ID
- Batch_ID
- PDF_Page
- Printed_Page
- Source_Order
- Record_Type
- Section
- Entity
- Description
- source columns
- calculated columns
- variance columns
- Row_Check
- Review_Status
- Exception_ID
- Decision_ID
- Source_Reference
- Source_File_SHA256
- Rendered_Page_SHA256
- Reviewer_Note
- Footnote_Code

## Record types

At minimum:

- Detail
- Continued detail
- Subtotal
- Deduction
- Reserve
- Grand total
- Narrative
- Footnote
- Source control
- Calculated control
- Exception
- Signature

## Formula rules

- all derived values are formulas
- no hardcoded subtotals
- no circular references
- formulas must exclude their own total row
- use explicit row ranges
- use structured tables when they improve traceability
- avoid volatile formulas unless necessary
- do not hide error-handling that masks bad inputs
- cross-sheet totals should reference the supporting schedule
- source totals should not be replaced by formulas
- use a separate calculated-total field

## Required check columns

For financial rows:

- Calculated_Total
- Calculated_Balance or Calculated_Excess
- Variance
- Row_Check

For source subtotals:

- Printed_Source_Total
- Calculated_Detail_Total
- Difference
- Expected_Difference
- Status
- Exception_ID

## Cross-sheet design

Build a Linkage Matrix with:

- Link_ID
- relationship
- left control
- left value
- right control
- right value
- difference
- expected difference
- status
- evidence
- notes

Replace duplicated hardcoded statement values with formulas to supporting schedules when the relationship is clear and the source design supports it.

## Formatting

- freeze headers
- wrap long descriptions
- set readable column widths
- use consistent number formats
- use red formatting for negative values
- landscape for wide schedules
- fit to width
- repeat header row on print pages when supported
- show page, batch, and section in titles
- render key views for visual inspection

## Macro policy

Default: no VBA, macros, or external links.

Use macros only when the user explicitly authorizes them and the downstream environment permits them.
