# Versioning, Packaging, and Recovery

## Version rule

Never overwrite an approved master.

Use monotonic versions:

- batch workbook: `PROJECT_Bxx_DESCRIPTION_v01.xlsx`
- cumulative master: `PROJECT_MASTER_after_Bxx_vNNN.xlsx`
- final master: `PROJECT_FINAL_MASTER_vNNN.xlsx`

## Checkpoint rule

Create a durable checkpoint after:

- preflight and batch plan
- every approved batch
- every corrected approved batch
- final extraction
- final integration

## Export verification

After export:

1. confirm file exists
2. confirm non-zero size
3. reload workbook
4. inspect key ranges
5. rescan formula errors
6. rescan exact failure values
7. render key sheets
8. calculate SHA-256
9. record export timestamp and tool version

## Recovery procedure

If the workbook process, kernel, or tool fails:

1. stop writing
2. preserve logs
3. identify latest approved exported master
4. verify its SHA-256
5. reload that version
6. compare Batch Control and Changelog
7. resume only the unapproved batch
8. do not reconstruct approved work from memory
9. document the interruption in the Changelog

## Delivery package

Use this BagIt-compatible structure:

```text
PROJECT_FINAL_Delivery/
├── bagit.txt
├── bag-info.txt
├── manifest-sha256.txt
├── tagmanifest-sha256.txt
└── data/
    ├── source/
    │   └── original_source.pdf
    ├── workbooks/
    │   ├── PROJECT_FINAL_MASTER_vNNN.xlsx
    │   ├── PROJECT_Final_Integration_v01.xlsx
    │   └── PROJECT_Completion_Plan_FINAL.xlsx
    ├── audit/
    │   ├── FINAL_Audit_Report.md
    │   ├── Publication_Manifest.md
    │   └── README.md
    └── renders/
        ├── controls_verification.png
        ├── statements_verification.png
        └── schedules_verification.png
```

A conventional ZIP may contain this structure.

## Bag metadata

`bag-info.txt` should include:

- Source-Organization
- Organization-Address, if applicable
- External-Identifier
- Bagging-Date
- Bag-Software-Agent
- Payload-Oxum
- Project-ID
- Final-Master
- Source-SHA256
- Page-Count
- Approved-Batches
- Accepted-Exceptions
- Validation-Status

## SHA-256

Use SHA-256 for:

- original source
- every authoritative workbook
- audit report
- publication manifest
- final render panels
- final package payload

Do not use the hash as proof of correctness. It proves that a file has not changed since the digest was generated.

## Authoritative-file rule

The final README and manifest must identify exactly one authoritative master.

Historical batch workbooks remain audit evidence and must not be presented as equivalent final versions.
