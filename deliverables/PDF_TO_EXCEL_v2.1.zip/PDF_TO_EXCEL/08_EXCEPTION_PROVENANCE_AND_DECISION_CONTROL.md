# Exception, Provenance, and Decision Control

## Principle

Source discrepancies are evidence. They are not inconveniences to erase.

## Exception taxonomy

| Code | Type |
|---|---|
| ARITH | Source arithmetic variance |
| ROW | Row-level source variance |
| SUBTOTAL | Source subtotal variance |
| TOTAL | Source grand-total variance |
| ROUND | Rounding variance |
| HEADING | Heading or section anomaly |
| NARRATIVE | Narrative-to-statement variance |
| PERCENT | Percentage variance |
| TABLE | Displayed table-total variance |
| OCR | OCR or text-layer conflict |
| IMAGE | Source-image ambiguity |
| CLASS | Classification ambiguity |
| MISSING | Missing or unreadable source value |
| LINK | Cross-sheet linkage difference |
| FORMAT | Source formatting ambiguity |

## Exception ID

Use:

`EXC-<PROJECT>-<BATCH>-<SEQUENCE>`

Example:

`EXC-A8407-B07-006`

## Exception Register fields

- Exception_ID
- Project_ID
- Batch_ID
- PDF_Page
- Printed_Page
- Record_ID
- Source_Order
- Exception_Type
- Description
- Printed_Source_Value
- Calculated_or_Linked_Value
- Difference
- Evidence
- Investigation_Steps
- Disposition
- Expected_Difference
- Status
- Reviewer
- Approved_Version
- Notes

## Investigation before acceptance

1. Re-render the page.
2. Inspect at 100% and enlarged crop.
3. Compare the original PDF view.
4. Check text layer as a locator.
5. Verify neighboring rows.
6. Recalculate independently.
7. Check page and batch totals.
8. Confirm no duplicate or missing row.
9. Confirm row type.
10. Only then accept a source discrepancy.

## Dispositions

- Corrected transcription error
- Accepted source arithmetic variance
- Accepted source subtotal variance
- Accepted source heading anomaly
- Accepted source narrative variance
- Accepted source percentage variance
- Accepted source table-total variance
- Unresolved — user input required
- Unreadable — preserved as missing
- Out of scope

## Decision Log

Use for non-error judgments such as:

- section classification
- row continuation
- batch boundary
- blank versus source marker
- linkage design
- formula convention
- print-layout decision

Decision records must remain reversible.

## Provenance model

Use a practical W3C PROV-inspired model.

### Entities

- original PDF
- PDF page
- rendered page image
- crop image
- source row
- batch workbook
- cumulative master
- audit report
- final package

### Activities

- rendering
- rotation
- transcription
- calculation
- review
- reconciliation
- export
- validation
- packaging

### Agents

- analyst
- assurer
- approver
- software/tool version

## Minimum provenance fields

- Source_File
- Source_File_SHA256
- PDF_Page
- Printed_Page
- Rendered_Image
- Rendered_Image_SHA256
- Record_ID
- Batch_ID
- Source_Order
- Extracted_By
- Extracted_At
- Reviewed_By
- Reviewed_At
- Derived_From
- Exception_ID
- Decision_ID
- Workbook_Version

## Question Log

Every user question must record:

- Question_ID
- blocking condition
- page or file
- question
- proposed default
- options
- answer
- effect on output
- date
